"""Tiny translation helper.

Source strings are English; Turkish translations live in the TR table below.
No gettext, no .mo files; the string table is small enough to keep in code.
"""

import os

_lang = "en"


def resolve(code):
    """'auto' -> language guessed from the locale environment."""
    if code in ("tr", "en"):
        return code
    env = (os.environ.get("LC_ALL") or os.environ.get("LC_MESSAGES")
           or os.environ.get("LANG") or "")
    return "tr" if env.lower().startswith("tr") else "en"


def set_language(code):
    global _lang
    _lang = resolve(code)


def language():
    return _lang


def t(text, /, **kwargs):
    # The string is positional-only so that every name is free to be a
    # placeholder: t("Discarded: {text}", text=…) would otherwise be two values
    # for one argument, and fail at the moment the message is shown.
    out = TR.get(text, text) if _lang == "tr" else text
    return out.format(**kwargs) if kwargs else out


# Turkish suffixes follow the vowels of the word they attach to, so "Claude'a"
# but "Codex'e". A name dropped into a sentence through t() cannot be inflected
# by the sentence, so it arrives already inflected. English takes the name as it
# is and puts the preposition in the sentence, where it belongs.
_TR_CASES = {
    "dative": {
        "Claude": "Claude'a", "Codex": "Codex'e", "OpenRouter": "OpenRouter'a",
        "Google AI Studio": "Google AI Studio'ya", "DeepSeek": "DeepSeek'e",
        "Antigravity": "Antigravity'ye", "OpenCode Go": "OpenCode Go'ya", "Requesty": "Requesty'ye",
    },
    "accusative": {
        "Claude": "Claude'u", "Codex": "Codex'i", "OpenRouter": "OpenRouter'ı",
        "Google AI Studio": "Google AI Studio'yu", "DeepSeek": "DeepSeek'i",
        "Antigravity": "Antigravity'yi", "OpenCode Go": "OpenCode Go'yu", "Requesty": "Requesty'yi",
    },
}


def name(text, /, case=""):
    if _lang != "tr" or not case:
        return text
    return _TR_CASES.get(case, {}).get(text, text)


TR = {
    "Theme": "Tema",
    "Classic dark": "Klasik karanlık",
    "Classic light": "Klasik beyaz",
    "Local": "Yerel",
    "Local GPU": "Yerel GPU",
    "Local CPU": "Yerel CPU",
    "Model not selected": "Model seçilmedi",
    "{name} default model": "{name} varsayılan modeli",
    "Dictation: {sound} / Cleanup: {text}": "Dikte: {sound} / Temizleme: {text}",
    "Minutes: {model}": "Tutanak: {model}",
    "Assistant: {model}": "Asistan: {model}",
    "Completed with a warning: {error}": "Uyarıyla tamamlandı: {error}",
    "Dikte: completed with a warning": "Dikte: uyarıyla tamamlandı",
    "Connect OpenRouter in Settings to write minutes. The recording is kept if writing fails.": "Tutanak yazmak için ayarlardan OpenRouter bağlantısını kurun. Tutanak yazılamazsa kayıt korunur.",
    "Set up assistant": "Asistanı ayarla",
    "Install the selected assistant CLI or configure its connection in Settings.": "Seçili asistanın CLI uygulamasını kurun veya ayarlardan bağlantısını yapılandırın.",
    "The local editing model is missing. Set it up in Settings; the original transcript is kept if editing fails.": "Yerel düzenleme modeli eksik. Ayarlardan yapılandırın; düzenleme başarısız olursa ham metin korunur.",
    # Compact desktop workspace.
    'Audio: {sound}\nText: {text}': 'Ses: {sound}\nMetin: {text}',
    'This computer': 'Bu bilgisayar',
    'Editing off': 'Düzenleme kapalı',
    'Record your microphone and the other participants. Use headphones.': 'Mikrofonunuzu ve diğer katılımcıları kaydedin. Kulaklık kullanın.',
    'Minutes: OpenRouter': 'Tutanak: OpenRouter',
    'Use the shortcut in the app where you want to write.': 'Yazmak istediğiniz uygulamada kısayola basın.',
    'Button recordings stay here and are copied to the clipboard.': 'Düğmeyle başlattığınız kayıtların metni burada kalır ve panoya kopyalanır.',
    'Latest text': 'Son metin',
    'Your first transcript will appear here.': 'İlk kaydınızın metni burada görünecek.',
    'Open text': 'Metni aç',
    'Assistant reply': 'Asistan yanıtı',
    "The assistant's reply will appear here.": 'Asistanın yanıtı burada görünecek.',
    'Ready to speak': 'Konuşmaya hazır',
    'Set up transcription': 'Yazıya çevirmeyi ayarla',
    'Automatic language': 'Dil otomatik',
    '{mic} / {language}': '{mic} / {language}',
    'Meeting recording is not supported on this system. You can still transcribe a file.': 'Bu sistemde toplantı kaydı desteklenmiyor. Ses dosyalarını yazıya çevirebilirsiniz.',
    '{name}\nPermissions: {permission}\nWorking directory: {directory}\nShortcut: {shortcut}\nThis button sends a spoken command to the assistant. Its reply is copied without automatic pasting.': '{name}\nYetkiler: {permission}\nÇalışma dizini: {directory}\nKısayol: {shortcut}\nBu düğme asistana sesli komut gönderir. Yanıtı otomatik yapıştırılmadan kopyalanır.',
    '{name} CLI (provider connection)': '{name} CLI (sağlayıcı bağlantısı)',
    'Assistant: {name}': 'Asistan: {name}',
    'Settings': 'Ayarlar',
    'Back to dictation': 'Dikteye dön',
    'Open selected text': 'Seçili metni aç',
    'Paused': 'Duraklatıldı',
    'Choose a connection or download a local model in Settings.': 'Ayarlardan bir bağlantı seçin veya yerel model indirin.',
    'On macOS, set up BlackHole or Loopback and select the system audio source in Settings first.': 'macOS üzerinde önce BlackHole veya Loopback kurun ve ayarlardan sistem sesi kaynağını seçin.',
    'Stop and send command': 'Bitir ve komutu gönder',
    "Uses the CLI's configured permissions": 'CLI için yapılandırılmış yetkileri kullanır',
    'Chat provider; no local command execution': 'Sohbet sağlayıcısı; yerel komut çalıştırmaz',
    'Record a command': 'Sesli komut kaydet',
    'Automatic permission decisions': 'İzin kararları otomatik',
    'Only actions that need no permission': 'Yalnız izin gerektirmeyen işlemler',
    'All permissions allowed': 'Tüm izinler açık',
    'Not used': 'Kullanılmıyor',
    'Not assigned': 'Atanmamış',
    'Assistant': 'Asistan',
    'Read files; write in the working directory': 'Dosyaları oku; çalışma dizinine yaz',
    'Open Dikte': 'Dikteyi aç',
    '{error}\n\nThe recording has been kept. Meeting → Minutes can try again.': '{error}\n\nKayıt korundu. Toplantı → Tutanaklar bölümünden yeniden deneyebilirsiniz.',
    'Original text kept, cleanup failed: {error}': 'Ham metin korundu, düzenleme başarısız: {error}',
    'Transcript ready: {preview}': 'Metin hazır: {preview}',
    'Editing did not finish. The original text was kept. {error}': 'Düzenleme tamamlanamadı. Ham metin korundu. {error}',
    'Transcript ready': 'Metin hazır',
    'Text editing and dictionary': 'Metin düzenleme ve sözlük',
    'Settings category': 'Ayar kategorisi',
    'Apply changes': 'Değişiklikleri uygula',
    'Discard changes': 'Değişikliklerden vazgeç',
    'Unsaved changes': 'Kaydedilmemiş değişiklikler',
    'Dictionary': 'Sözlük',
    'File': 'Dosya',

    # --- tray ---------------------------------------------------------
    "Start recording": "Kaydı başlat",
    "Working…": "İşleniyor…",
    "Pause the recording": "Kaydı duraklat",
    "Resume the recording": "Kayda devam et",
    "Discard the recording": "Kaydı iptal et",
    "Settings…": "Ayarlar…",
    "Restart": "Yeniden başlat",
    "Quit": "Çık",
    "Dikte: ready": "Dikte: hazır",
    "Dikte: recording": "Dikte: kaydediyor",
    "Dikte: paused": "Dikte: duraklatıldı",
    "Dikte: working": "Dikte: işleniyor",

    # --- overlay / pipeline -------------------------------------------
    "Transcribing…": "Yazıya çevriliyor…",
    "Waiting for the one before it…": "Öncekinin bitmesi bekleniyor…",
    "Cleaning up…": "Temizleniyor…",
    "Pasting…": "Yapıştırılıyor…",
    "Pasted": "Yapıştırıldı",
    "Copied": "Kopyalandı",
    "{action}: {preview}": "{action}: {preview}",
    "Cleanup skipped: {error}": "Temizleme atlandı: {error}",
    "Pasted raw, cleanup failed: {error}": "Ham metin yapıştırıldı, temizleme başarısız: {error}",
    "Dikte: cleanup failed": "Dikte: temizleme başarısız",
    "{service} rejected the API key (HTTP {code}). Open Settings and check it.":
        "{service} API anahtarını reddetti (HTTP {code}). Ayarlar'ı açıp kontrol et.",
    "{service} says the account is out of credit (HTTP 402).":
        "{service} hesapta kredi kalmadığını söylüyor (HTTP 402).",
    "{service} is rate limiting you (HTTP 429). Try again in a moment.":
        "{service} hız sınırı uyguluyor (HTTP 429). Birazdan tekrar dene.",
    "{error} Retrying in {seconds} s ({attempt}/{total})…":
        "{error} {seconds} sn sonra yeniden deneniyor ({attempt}/{total})…",
    "The {desktop} shortcut is live now, so the built-in listener has "
    "been turned off. It was doubling every key press.":
        "{desktop} kısayolu artık çalışıyor, bu yüzden dahili dinleyici kapatıldı. "
        "Her tuşa basışı ikiye katlıyordu.",
    "No speech detected": "Ses algılanmadı",
    "No speech detected ({level} dB)": "Ses algılanmadı ({level} dB)",
    "Discarded a stock phrase: “{text}”": "Kalıp cümle atıldı: “{text}”",
    "Discard stock phrases models invent for near-silent audio":
        "Sessize yakın seste modelin uydurduğu kalıp cümleleri at",
    "Play audio cues when recording changes":
        "Kayıt durumu değiştiğinde sesli uyarı çal",
    "A short pattern marks recording start, stop, completion and failure.":
        "Kısa bir ses deseni kaydın başlamasını, bitmesini, tamamlanmasını ve başarısız olmasını belirtir.",
    "Whisper answers silence with things like “Thanks for watching”.":
        "Whisper sessizliğe “Altyazı M.K.” gibi şeylerle karşılık verir.",
    "Speech also has to rise {margin} dB above the recording's own noise "
    "floor, so this absolute floor rarely needs touching. Lower it if quiet "
    "speech gets dropped; raise it if noise still gets through.":
        "Konuşmanın ayrıca kaydın kendi gürültü tabanının {margin} dB üstüne "
        "çıkması gerekir; bu mutlak taban nadiren değiştirilir. Kısık konuşma "
        "eleniyorsa düşür, gürültü hâlâ geçiyorsa yükselt.",
    "Recording too short, speak for at least 0.3 s": "Ses çok kısa, en az 0,3 saniye konuş",
    "Unexpected error: {error}": "Beklenmeyen hata: {error}",

    # --- audio / paste errors -----------------------------------------
    "Could not start recording: {error}": "Kayıt başlatılamadı: {error}",
    "No audio recorder found. Install pulseaudio-utils or pipewire-audio.":
        "Ses kayıt aracı bulunamadı. pulseaudio-utils ya da pipewire-audio kur.",
    "ffmpeg not found. Install it with: brew install ffmpeg":
        "ffmpeg bulunamadı. Şununla kur: brew install ffmpeg",
    "ffmpeg or a microphone was not found. Install ffmpeg with: "
    "winget install Gyan.FFmpeg":
        "ffmpeg ya da bir mikrofon bulunamadı. ffmpeg'i şununla kur: "
        "winget install Gyan.FFmpeg",
    "Audio recorder stopped before receiving sound: {error}":
        "Ses kayıt aracı veri alamadan kapandı: {error}",
    "Could not copy to clipboard: {error}": "Panoya kopyalanamadı: {error}",
    "{tool} not found. Install {packages}.":
        "{tool} bulunamadı. {packages} paketlerini kur.",
    "{tool} not found.": "{tool} bulunamadı.",
    "{tool} exited with code {code}.": "{tool} {code} koduyla çıktı.",
    "{tool} not found, cannot paste automatically.":
        "{tool} bulunamadı, otomatik yapıştırma yapılamıyor.",
    "Unknown key: {key}": "Bilinmeyen tuş: {key}",
    "Could not run {tool}: {error}": "{tool} çalıştırılamadı: {error}",
    "{tool} failed: {error}": "{tool} hatası: {error}",
    "Is ydotoold running? (systemctl --user status ydotool)":
        "ydotoold çalışıyor mu? (systemctl --user status ydotool)",
    "macOS has not been told to let Dikte press keys. Turn Dikte on under "
    "System Settings → Privacy & Security → Accessibility.":
        "macOS, Dikte'nin tuşlara basmasına henüz izin vermiyor. Sistem Ayarları "
        "→ Gizlilik ve Güvenlik → Erişilebilirlik altında Dikte'yi aç.",

    # --- api errors ----------------------------------------------------
    "{service} API key is empty. Add it in Settings.":
        "{service} API anahtarı boş. Ayarlar'dan gir.",
    "{service} address is empty. Add it in Settings.":
        "{service} adresi boş. Ayarlar'dan gir.",
    "{service} address must start with http:// or https://.":
        "{service} adresi http:// ya da https:// ile başlamalı.",
    "Transcript came back empty.": "Transkript boş döndü.",
    "The cleanup model returned an empty reply.": "Temizleme modeli boş yanıt döndü.",
    "Could not connect: {reason}": "Bağlantı kurulamadı: {reason}",
    "Could not parse the response: {error}": "Yanıt çözümlenemedi: {error}",

    "Graphics capability unknown. The active backend is reported after "
    "whisper.cpp starts.":
        "Grafik desteği bilinmiyor. Etkin arka uç whisper.cpp başladıktan sonra "
        "gösterilir.",
    "Installed on the system: whisper.cpp {version}\n{path}":
        "Sistemde kurulu: whisper.cpp {version}\n{path}",
    "No macOS server download is available here. Install it with "
    "`brew install whisper.cpp`, then reopen Settings. Dikte detects "
    "Homebrew's whisper-server automatically. A build of your own goes in with "
    "`dikte config set local_binary <path>`.":
        "Buradan indirilebilen bir macOS sunucusu yok. "
        "`brew install whisper.cpp` ile kur, ardından Ayarlar'ı yeniden aç. "
        "Dikte, Homebrew'un whisper-server programını otomatik bulur. "
        "Kendi derlemeni `dikte config set local_binary <yol>` ile verebilirsin.",

    # --- settings: tabs and general ------------------------------------
    "Dikte Settings": "Dikte Ayarları",
    "General": "Genel",
    "Display": "Ekran",
    "API and models": "API ve modeller",
    "Cleanup rules": "Temizleme kuralları",
    "Audio file": "Ses dosyası",
    "Shortcut": "Kısayol",
    "Shortcuts": "Kısayollar",
    "History": "Geçmiş",
    "Save": "Kaydet",
    "Saved successfully.": "Başarıyla kaydedildi.",
    "Interface language": "Arayüz dili",
    "Automatic (system)": "Otomatik (sistem)",
    "Turkish": "Türkçe",
    "English": "İngilizce",
    "Microphone": "Mikrofon",
    "Default microphone": "Varsayılan mikrofon",
    "Speech language": "Konuşma dili",
    "Detect automatically": "Otomatik algıla",
    "German": "Almanca",
    "French": "Fransızca",
    "Spanish": "İspanyolca",
    "Arabic": "Arapça",
    "Paste the text into the focused window": "Metni odaktaki pencereye yapıştır",
    "Paste key": "Yapıştırma tuşu",
    "Terminals usually want ctrl+shift+v. Change this if pasting does nothing.":
        "Terminaller genelde ctrl+shift+v ister. Yapıştırma çalışmıyorsa bunu değiştir.",
    "macOS asks for Accessibility permission the first time this is sent.":
        "macOS bu ilk gönderildiğinde Erişilebilirlik izni ister.",
    "Restore the previous clipboard after pasting":
        "Yapıştırdıktan sonra eski pano içeriğini geri koy",
    "Indicator screen": "Gösterge ekranı",
    "Follow the active screen": "Etkin ekranı takip et",
    "{name} (not connected)": "{name} (bağlı değil)",
    "Move it when the active screen changes":
        "Etkin ekran değiştiğinde göstergeyi de taşı",
    "Indicator corner": "Gösterge köşesi",
    "bottom-left": "sol-alt",
    "bottom-right": "sağ-alt",
    "top-left": "sol-üst",
    "top-right": "sağ-üst",
    "Longest recording": "En uzun kayıt",
    " s": " sn",
    "Silence threshold": "Sessizlik eşiği",
    "Keep audio files ({path})": "Ses kayıtlarını sakla ({path})",

    # --- updates --------------------------------------------------------
    "Updates": "Güncelleme",
    "Look for a newer version once a day": "Günde bir kez yeni sürüm var mı diye bak",
    "Start in the tray when I log in": "Oturum açınca tepside başlat",
    "Only the start at login. Opening Dikte from the menu always shows the "
    "window, and so does a first start that still needs setting up.":
        "Yalnızca oturum açılışındaki başlatma için. Dikte'yi menüden açmak "
        "pencereyi her zaman gösterir; kurulumu bitmemiş ilk açılış da öyle.",
    "Dikte only looks. What it finds opens the release page in your browser; "
    "it downloads and installs nothing by itself.":
        "Dikte yalnızca bakar. Bulduğu şey tarayıcında sürüm sayfasını açar; "
        "kendi başına hiçbir şey indirmez ve kurmaz.",
    "Check now": "Şimdi bak",
    "Looking…": "Bakılıyor…",
    "Open the release page": "Sürüm sayfasını aç",
    "This is Dikte {version}.": "Buradaki sürüm Dikte {version}.",
    "Dikte {version} is the newest release.": "En yeni sürüm zaten bu: Dikte {version}.",
    "Dikte {version} is out; this is {current}.":
        "Dikte {version} çıkmış; buradaki sürüm {current}.",
    "Dikte {version} is out…": "Dikte {version} çıkmış…",
    "Dikte {version} is out. The tray menu has the release page.":
        "Dikte {version} çıkmış. Sürüm sayfası tepsi menüsünde.",
    "{repo} has published no release.": "{repo} için yayımlanmış sürüm yok.",

    # --- settings: api --------------------------------------------------
    "Keys": "Anahtarlar",
    "Speech to text": "Sesi yazıya çevirme",
    "Transcript cleanup": "Transkripti temizleme",
    "Preset": "Hazır ayar",
    "Other": "Diğer",
    "Optional": "İsteğe bağlı",
    "Choose Other to edit the address.": "Adresi düzenlemek için Diğer seçeneğini seç.",
    "Empty uses {variable}.": "Boşsa {variable} kullanılır.",
    "{service} does not support transcription.": "{service} sesi yazıya çevirmeyi desteklemiyor.",
    "API key": "API anahtarı",
    "Model": "Model",
    "Audio file model": "Ses dosyası modeli",
    "The model a timestamped audio file (subtitles) is sent to. Not every model on "
    "OpenRouter returns segment times; empty means openai/whisper-1.":
        "Zaman damgalı bir ses dosyasının (altyazı) gönderildiği model. OpenRouter'daki her "
        "model segment zamanı döndürmez; boşsa openai/whisper-1 kullanılır.",
    "Provider": "Sağlayıcı",
    "sk-… (falls back to OPENAI_API_KEY)": "sk-… (boşsa OPENAI_API_KEY kullanılır)",
    "sk-or-… (falls back to OPENROUTER_API_KEY)": "sk-or-… (boşsa OPENROUTER_API_KEY kullanılır)",
    "Custom server": "Özel sunucu",
    "Custom server address": "Özel sunucu adresi",
    "Address": "Adres",
    "Connection works. {count} models visible.":
        "Bağlantı tamam. {count} model görünüyor.",
    "Empty: the server's default model": "Boş: sunucunun varsayılan modeli",
    "Pick a model from the list": "Listeden bir model seçin",
    "Choose a {service} model in Settings.": "Ayarlar'da bir {service} modeli seçin.",
    "Test": "Test et",
    "Trying…": "Deneniyor…",
    "Runs on OpenRouter.": "OpenRouter üzerinde çalışır.",
    "Runs on your custom server.": "Özel sunucunda çalışır.",
    "Connection works. {count} audio models visible.":
        "Bağlantı tamam. {count} ses modeli görünüyor.",
    "Clean the transcript with a model": "Transkripti bir modelle temizle",
    "{binary} is not on your PATH, so cleanup would fail and the raw transcript "
    "would be pasted. Install it, or pick another one above.":
        "{binary} PATH'te değil; temizleme başarısız olur ve ham transkript "
        "yapıştırılır. Kur ya da yukarıdan başka birini seç.",
    "Thinking": "Düşünme",
    "Model's own default": "Modelin kendi varsayılanı",
    "Antigravity's own default": "Antigravity'nin kendi varsayılanı",
    "Off": "Kapalı",
    "Minimal": "En az",
    "Low": "Düşük",
    "Medium": "Orta",
    "High": "Yüksek",
    "Very high": "Çok yüksek",
    "Maximum": "En yüksek",
    "How long a thinking model may reason before it answers. Cleanup is a light "
    "job, so more thinking mostly costs time and tokens. Models that cannot "
    "think ignore this.":
        "Düşünebilen bir modelin yanıtlamadan önce ne kadar düşüneceği. Temizleme "
        "hafif bir iş, fazla düşünmenin çoğunlukla getirisi süre ve token. "
        "Düşünemeyen modeller bunu yok sayar.",
    "Fetch model list": "Model listesini çek",
    "Fetching model list…": "Model listesi çekiliyor…",
    "Could not fetch the list: {error}": "Liste alınamadı: {error}",
    "{count} models loaded.": "{count} model yüklendi.",
    "Key works, no spending limit set.": "Anahtar çalışıyor, harcama sınırı yok.",
    "Key works. Used {usage} of {limit}.":
        "Anahtar çalışıyor. {limit} sınırının {usage} kadarı kullanılmış.",

    # --- settings: prompt ------------------------------------------------
    "System instruction given to the cleanup model. This is where you decide "
    "how much it may touch your words.":
        "Temizleme modeline verilen sistem talimatı. Ne kadar müdahale edeceğini "
        "burada belirlersin.",
    "Dictation": "Dikte",
    "Used instead when an audio or video file is cleaned up. It is written for "
    "subtitles: lines stay where they are, nothing is shortened, and misheard "
    "words are repaired from the context.":
        "Bir ses ya da video dosyası temizlenirken bunun yerine bu kullanılır. "
        "Altyazı için yazılmıştır: satırlar yerinde kalır, hiçbir şey kısaltılmaz, "
        "yanlış duyulan kelimeler bağlamdan düzeltilir.",
    "Reset to default": "Varsayılana döndür",
    "Names and terms you say often (optional). They go to the transcription "
    "model as a hint, and to the cleanup model as a glossary, so it can repair "
    "the ones that still come out wrong.":
        "Sık kullandığın isimler ve terimler (isteğe bağlı). Transkripsiyon "
        "modeline ipucu, temizleme modeline sözlük olarak gider; böylece yanlış "
        "çıkanları düzeltebilir.",

    # --- settings: audio file --------------------------------------------
    "Transcribe an existing audio or video file with the same models.":
        "Var olan bir ses ya da video dosyasını aynı modellerle yazıya çevir.",
    "Choose file…": "Dosya seç…",
    "No file selected": "Dosya seçilmedi",
    "Select an audio file": "Bir ses dosyası seç",
    "Audio and video files": "Ses ve video dosyaları",
    "All files": "Tüm dosyalar",
    "Add timestamps": "Zaman damgası ekle",
    "Tell the speakers apart": "Konuşmacıları ayır",
    "Puts who is talking in front of every line. Only offered for the models known "
    "to label speakers.":
        "Her satırın başına kimin konuştuğunu yazar. Yalnızca konuşmacıları "
        "etiketlediği bilinen modellerde çıkar.",
    "Speaker {number}": "Konuşmacı {number}",
    "{model} cannot tell speakers apart.": "{model} konuşmacıları ayıramıyor.",
    "{service} returns no timestamps.": "{service} zaman damgası döndürmüyor.",
    "{service} returns no timestamps, so it cannot make subtitles or meeting "
    "transcripts. Pick another speech to text provider in Settings.":
        "{service} zaman damgası döndürmediği için altyazı ya da toplantı dökümü "
        "çıkaramıyor. Ayarlar'dan başka bir yazıya çevirme sağlayıcısı seç.",
    "Gives no timestamps, so subtitles and meetings need another provider.":
        "Zaman damgası vermez, altyazı ve toplantılar için başka bir sağlayıcı gerekir.",
    "{service} takes at most {size} MB of audio in one request.":
        "{service} tek istekte en fazla {size} MB ses kabul ediyor.",
    "{service} spent its whole reply on thinking and wrote no transcript.":
        "{service} bütün yanıtını düşünmeye harcadı ve döküm yazmadı.",
    "{service} wrote no transcript ({reason}).":
        "{service} döküm yazmadı ({reason}).",
    "Prefixes every segment with [mm:ss]. Uses whisper-1 on whichever provider "
    "you picked, the only model that returns segment times.":
        "Her bölümün başına [dd:ss] koyar. Bölüm zamanı döndüren tek model olan "
        "whisper-1, seçtiğin sağlayıcı üzerinden kullanılır.",
    "Run the cleanup model afterwards": "Sonrasında temizleme modelinden geçir",
    "With its own rules, under Cleanup rules: written for subtitles, so the "
    "lines keep their place and nothing is shortened.":
        "Kendi kurallarıyla, Temizleme kuralları sekmesinin altında: altyazı için "
        "yazılmıştır, satırlar yerinde kalır ve hiçbir şey kısaltılmaz.",
    "Break long subtitle lines": "Uzun altyazı satırlarını böl",
    "Splits a cue longer than 42 characters into balanced lines in the .srt. "
    "The text and timing stay the same.":
        "'.srt' dosyasında 42 karakterden uzun altyazıyı dengeli satırlara böler. "
        "Metin ve zamanlama aynı kalır.",
    "Transcribe": "Yazıya çevir",
    "Stop": "Durdur",
    "Copy": "Panoya kopyala",
    "Save as .txt": "'.txt' olarak kaydet",
    "Save as .srt": "'.srt' olarak kaydet",
    "Subtitles, timed from the segments. Needs the timestamps option.":
        "Altyazı; zamanlaması bölüm damgalarından gelir. Zaman damgası seçeneği "
        "işaretliyken çalışır.",
    "No timestamped lines to turn into subtitles.":
        "Altyazıya çevrilecek zaman damgalı satır yok.",
    "Save transcript": "Transkripti kaydet",
    "Text files": "Metin dosyaları",
    "Subtitle files": "Altyazı dosyaları",
    "Converting audio…": "Ses dönüştürülüyor…",
    "Splitting into {count} chunks…": "{count} parçaya bölünüyor…",
    "Transcribing chunk {index}/{count}…": "{index}/{count} parça yazıya çevriliyor…",
    "{error} Trying again ({attempt}/{total})…":
        "{error} Yeniden deneniyor ({attempt}/{total})…",
    "{error} The transcript up to there is below.":
        "{error} Oraya kadar çevrilen metin aşağıda.",
    "Done: {chars} characters.": "Bitti: {chars} karakter.",
    "Stopped.": "Durduruldu.",
    "Failed: {error}": "Başarısız: {error}",
    "ffmpeg not found. Install it to transcribe files.":
        "ffmpeg bulunamadı. Dosya çevirmek için kur.",
    "Could not read the file: {error}": "Dosya okunamadı: {error}",
    "Saved: {path}": "Kaydedildi: {path}",

    # --- settings: shortcut ------------------------------------------------
    "Install as a {desktop} shortcut": "{desktop} kısayolu olarak kur",
    "Install as a global shortcut": "Global kısayol olarak kur",
    "Remove": "Kaldır",
    "Registered in KDE: {shortcut}": "KDE'de kayıtlı: {shortcut}",
    "No KDE shortcut installed.": "KDE kısayolu kurulu değil.",
    "Registered in {desktop}: {shortcut}": "{desktop}'da kayıtlı: {shortcut}",
    "Held by Dikte while it runs: {shortcut}":
        "Dikte çalıştığı sürece tutuyor: {shortcut}",
    "No global shortcut installed.": "Global kısayol kurulu değil.",
    "No global shortcut installed. The tray menu starts a meeting too.":
        "Global kısayol kurulu değil. Toplantı tepsi menüsünden de başlatılabilir.",
    "No global shortcut installed. The tray menu asks it too.":
        "Global kısayol kurulu değil. Tepsi menüsünden de soru sorulabilir.",
    "No global shortcut installed. The tray menu discards it too.":
        "Global kısayol kurulu değil. Kayıt tepsi menüsünden de iptal edilebilir.",
    "No global shortcut installed. The tray menu holds it too.":
        "Global kısayol kurulu değil. Kayıt tepsi menüsünden de duraklatılabilir.",
    "Start and stop": "Başlat ve bitir",
    "Pause and resume": "Duraklat ve devam et",
    "Holds the recording without ending it. Nothing said while it is paused is "
    "kept, and the clock stops with it.":
        "Kaydı bitirmeden duraklatır. Duraklatıldığı sürede konuşulanlar "
        "kaydedilmez, süre sayacı da onunla birlikte durur.",
    "Throws the recording away without transcribing it. Works on a dictation "
    "and on a command for the assistant alike, whichever is running.":
        "Kaydı yazıya dökmeden atar. Hangisi çalışıyorsa ona işler: dikteye de, "
        "asistana verilen komuta da.",
    "Shortcut saved: {shortcut}": "Kısayol kaydedildi: {shortcut}",
    "Could not register the GNOME shortcut: {error}":
        "GNOME kısayolu kaydedilemedi: {error}",
    "Use the built-in listener (/dev/input), for when the {desktop} shortcut "
    "is not active yet":
        "Yerleşik dinleyici kullan (/dev/input), {desktop} kısayolu henüz etkin "
        "değilken",
    "Works immediately, no session restart. The only difference: the key "
    "combination also reaches the focused application.":
        "Anında çalışır, oturum yenilemek gerekmez. Tek farkı: tuş kombinasyonu "
        "odaktaki uygulamaya da iletilir.",
    "KWin only reads shortcut settings at startup. After 'Install' the shortcut "
    "shows up under System Settings → Shortcuts, but it will not fire until you "
    "log out and back in. Until then, use the built-in listener.":
        "KWin, kısayol ayarlarını yalnızca açılışta okur. 'Kur' dedikten sonra kısayol "
        "Sistem Ayarları → Kısayollar altında görünür ama oturumu yeniden açana kadar "
        "tetiklenmez. O zamana kadar yerleşik dinleyiciyi kullanabilirsin.",
    "The shortcut starts working as soon as it is installed.":
        "Kısayol kurulur kurulmaz çalışmaya başlar.",
    "Dikte asks macOS for these combinations itself, while it is running. "
    "Nothing is installed, and no other application receives them in the "
    "meantime.":
        "Dikte bu kombinasyonları çalışırken macOS'tan kendisi ister. Hiçbir şey "
        "kurulmaz ve o sırada başka hiçbir uygulama bu tuşları almaz.",
    "Dikte asks Windows for these combinations itself, while it is running. "
    "Nothing is installed, and no other application receives them in the "
    "meantime.":
        "Dikte bu kombinasyonları çalışırken Windows'tan kendisi ister. Hiçbir şey "
        "kurulmaz ve o sırada başka hiçbir uygulama bu tuşları almaz.",
    "{desktop} keeps no shortcut registry, so Dikte listens for these "
    "combinations itself while it is running. Your user has to be able to read "
    "/dev/input for that, and the focused application receives the keys as "
    "well. To have the desktop own them instead, bind this command in its own "
    "configuration, with the last word swapped for pause, cancel, ask or "
    "meeting:":
        "{desktop} kısayol kaydı tutmaz, bu yüzden Dikte bu kombinasyonları "
        "çalıştığı sürece kendisi dinler. Bunun için kullanıcının /dev/input'u "
        "okuyabilmesi gerekir, ayrıca tuşlar odaktaki uygulamaya da iletilir. "
        "Tuşları masaüstünün sahiplenmesini istersen, son kelimeyi pause, "
        "cancel, ask veya meeting ile değiştirerek şu komutu kendi "
        "yapılandırmasında bir tuşa bağla:",
    "Shortcut conflict": "Kısayol çakışması",
    "{shortcut} is also used by:\n\n{list}\n\nInstall anyway?":
        "{shortcut} şu girdilerde de kullanılıyor:\n\n{list}\n\nYine de kurulsun mu?",
    "Shortcut saved: {shortcut}\nKWin only reads this file at startup, so it "
    "will not fire until you log out and back in. To use it right away, turn on "
    "the built-in listener.":
        "Kısayol kaydedildi: {shortcut}\nKWin bu dosyayı yalnızca açılışta okuduğu için "
        "oturumu yeniden açana kadar tetiklenmez. Hemen kullanmak istersen "
        "yerleşik dinleyiciyi aç.",
    "Could not write the desktop file: {error}": "Desktop dosyası yazılamadı: {error}",
    "Could not write kglobalshortcutsrc: {error}": "kglobalshortcutsrc yazılamadı: {error}",
    "Could not parse the shortcut: {shortcut}": "Kısayol çözümlenemedi: {shortcut}",
    "Shortcut saved: {shortcut}\nDikte holds this one itself while it is "
    "running, so it works as soon as the settings are saved.":
        "Kısayol kaydedildi: {shortcut}\nDikte bunu çalıştığı sürece kendisi "
        "tutar, yani ayarlar kaydedilir kaydedilmez çalışır.",
    "Shortcut saved: {shortcut}\n{desktop} has no shortcut registry to install "
    "into, so Dikte listens for this one itself while it is running. It works "
    "as soon as the settings are saved.":
        "Kısayol kaydedildi: {shortcut}\n{desktop} kurulacak bir kısayol kaydı "
        "tutmadığı için Dikte bunu çalıştığı sürece kendisi dinler. Ayarlar "
        "kaydedilir kaydedilmez çalışır.",
    "Could not reach the macOS shortcut service: {error}":
        "macOS kısayol servisine ulaşılamadı: {error}",
    "macOS would not give Dikte {shortcut}; another application already holds it.":
        "macOS {shortcut} kombinasyonunu Dikte'ye vermedi; başka bir uygulama "
        "onu şimdiden tutuyor.",
    "Could not reach the Windows shortcut service: {error}":
        "Windows kısayol servisine ulaşılamadı: {error}",
    "Windows would not give Dikte {shortcut}; another application already "
    "holds it.":
        "Windows {shortcut} kombinasyonunu Dikte'ye vermedi; başka bir uygulama "
        "onu şimdiden tutuyor.",
    "Cannot read /dev/input. Your user needs to be in the 'input' group:\n"
    "  sudo usermod -aG input $USER   (then log out and back in)":
        "/dev/input okunamıyor. Kullanıcının 'input' grubunda olması gerekir:\n"
        "  sudo usermod -aG input $USER   (sonra oturumu yeniden aç)",

    # --- settings: history --------------------------------------------------
    "Copy selected to clipboard": "Seçiliyi panoya kopyala",
    "Delete selected": "Seçiliyi sil",
    "Clear history": "Geçmişi temizle",
    "Reload": "Yenile",
    "{ts}  ({duration} s)": "{ts}  ({duration} sn)",
    "Keep at most": "En fazla",
    " entries": " kayıt",
    "no limit": "sınırsız",
    "Once the history passes this many entries, the oldest one is dropped "
    "every time a new one arrives. Set it to 0 to keep everything.":
        "Geçmiş bu sayıyı aştıktan sonra, her yeni kayıt geldiğinde en eski kayıt "
        "silinir. Hepsini tutmak için 0 yaz.",
    "Delete the {count} selected entries?": "Seçili {count} kayıt silinsin mi?",
    "Retry": "Tekrar dene",
    "Transcribe the kept recording of a failed dictation again. The "
    "text goes to the clipboard.":
        "Başarısız bir diktenin saklanan kaydını yeniden yazıya döker. Metin "
        "panoya kopyalanır.",
    "The recording was kept; select it and press Retry.":
        "Kayıt saklandı; seçip Tekrar dene'ye bas.",
    "The recording is no longer there: {path}": "Kayıt artık yerinde değil: {path}",
    "Delete the whole history? This cannot be undone.":
        "Geçmişin tamamı silinsin mi? Bu geri alınamaz.",

    # --- asking Claude Code -------------------------------------------------
    "Ask {name}": "{name} sor",
    "Stop and ask {name}": "Kaydı bitir ve {name} sor",
    "Start a new conversation": "Yeni konuşma başlat",
    "Start a new conversation now": "Şimdi yeni konuşma başlat",
    "Stop {name}": "{name} durdur",
    "Stopping…": "Durduruluyor…",
    "{name} starts fresh next time.": "{name} bir sonrakine sıfırdan başlayacak.",
    "Dikte: talking to Claude": "Dikte: asistanla konuşuyor",
    "Dikte: recording for Claude": "Dikte: asistan için kaydediyor",
    "Asking {name}…": "{name} soruluyor…",
    "{name}: {preview}": "{name}: {preview}",
    "{name} answered, but: {error}": "{name} cevapladı, ama: {error}",
    "Dikte: {name} could not do all of it": "Dikte: {name} her şeyi yapamadı",
    "Running a command…": "Komut çalıştırıyor…",
    "Reading…": "Okuyor…",
    "Looking through files…": "Dosyalara bakıyor…",
    "Searching the files…": "Dosyalarda arıyor…",
    "Editing a file…": "Dosya düzenliyor…",
    "Writing a file…": "Dosya yazıyor…",
    "Searching the web…": "İnternette arıyor…",
    "Reading a web page…": "Web sayfası okuyor…",
    "Handing it to a subagent…": "Alt ajana devrediyor…",
    "Planning…": "Planlıyor…",
    "Using {name}…": "{name} kullanıyor…",
    "Thinking…": "Düşünüyor…",
    "{binary} not found. Install it, or pick another provider under "
    "Settings → Assistant.":
        "{binary} bulunamadı. Kur ya da Ayarlar → Asistan sayfasından başka bir "
        "sağlayıcı seç.",
    "Could not run {binary}: {error}": "{binary} çalıştırılamadı: {error}",
    "{service} exited with code {code}.": "{service} {code} koduyla çıktı.",
    "It did not finish within {seconds} seconds.":
        "{seconds} saniye içinde bitmedi.",
    "Claude ended with an error.": "Claude bir hatayla sonlandı.",
    "Codex ended with an error.": "Codex bir hatayla sonlandı.",
    "{service} answered with nothing.": "{service} boş cevap verdi.",
    "It was not allowed to use: {tools}": "Şunları kullanmasına izin yoktu: {tools}",
    "The model returned an empty reply.": "Model boş cevap döndürdü.",

    # --- cleanup, when a CLI does it ----------------------------------------
    "{binary} not found. Install it, or have OpenRouter clean up instead, "
    "under Settings → API and models.":
        "{binary} bulunamadı. Kur ya da Ayarlar → API ve modeller sekmesinden "
        "temizliği OpenRouter'a bırak.",
    "{service} did not finish within {seconds} seconds.":
        "{service} {seconds} saniye içinde bitmedi.",

    # --- settings: the agent ------------------------------------------------
    "Agent": "Ajan",
    "How it runs": "Nasıl çalışıyor",
    "Runs on": "Şunun üstünde çalışır",
    "More thinking is slower, and you are standing in front of the screen while "
    "it happens. Worth it for a job that has to be worked out rather than "
    "looked up.":
        "Daha çok düşünmek daha yavaştır ve bu sırada ekranın başında bekliyor "
        "olursun. Bakılıp bulunacak değil, çözülmesi gereken işler için değer.",
    "Claude Code": "Claude Code",
    "Codex": "Codex",
    "Codex's own default": "Codex'in kendi varsayılanı",
    "Sandbox": "Kum havuzu",
    "Read anything, write in the working directory":
        "Her şeyi okusun, çalışma dizinine yazsın",
    "Read only": "Yalnızca okusun",
    "No sandbox at all": "Kum havuzu hiç olmasın",
    "A plain question and a plain answer, over the OpenRouter key you already "
    "have. It runs no commands, opens no files and reaches none of your "
    "services, so it can tell you what the capital of Peru is but not what is "
    "in your calendar. Working directory and permissions above mean nothing "
    "here.":
        "Elindeki OpenRouter anahtarı üzerinden düz bir soru ve düz bir cevap. "
        "Komut çalıştırmaz, dosya açmaz, servislerinin hiçbirine erişmez; yani "
        "Peru'nun başkentini söyler ama takviminde ne olduğunu söyleyemez. "
        "Yukarıdaki çalışma dizini ve izinler burada bir şey ifade etmez.",
    "Antigravity has neither a permission mode nor a sandbox to hand it, so "
    "what it may do without asking is whatever its own allow-rules say. The "
    "Permissions and Sandbox boxes above belong to the other two; the working "
    "directory still applies.":
        "Antigravity'ye verilebilecek bir izin kipi ya da sandbox yok; sormadan "
        "ne yapabileceğini kendi allow-rule'ları belirler. Yukarıdaki İzinler ve "
        "Sandbox kutuları diğer ikisine ait; çalışma dizini burada da geçerli.",
    "{binary} is not on your PATH, so this cannot run yet. Install it, or pick "
    "another one above.":
        "{binary} PATH'te değil, dolayısıyla bu henüz çalışamaz. Kur ya da "
        "yukarıdan başka birini seç.",
    "The conversation": "Konuşma",
    "The answer": "Cevap",
    "Found: {path}": "Bulundu: {path}",
    "No KDE shortcut installed. The tray menu asks it too.":
        "Kurulu KDE kısayolu yok. Tepsi menüsünden de sorulabilir.",
    "A name like “sonnet” always means the newest model of that line. Opus "
    "thinks harder and answers slower, which is felt here more than anywhere "
    "else: you are standing in front of the screen.":
        "“sonnet” gibi bir ad her zaman o serinin en yenisini seçer. Opus daha "
        "çok düşünür ve daha geç cevaplar; bu da en çok burada hissedilir, "
        "çünkü ekranın başında bekliyorsun.",
    "The list is a starting point, not a fence: any model name {name} accepts "
    "can be typed straight in.":
        "Liste başlangıç için, sınır değil: {name} hangi model adını kabul "
        "ediyorsa buraya elle yazılabilir.",
    "Permissions": "İzinler",
    "Decide on its own, with the safety checks on":
        "Kendi karar versin, güvenlik denetimleri açık",
    "Allow everything": "Her şeye izin ver",
    "Only what needs no permission": "Yalnızca izin gerektirmeyenler",
    "Working directory": "Çalışma dizini",
    "Choose…": "Seç…",
    "The directory the command runs in, which decides which project's "
    "instructions and files it can see. Your own skills and services are there "
    "whichever one it is.":
        "Komutun içinde çalıştığı dizin; hangi projenin talimatlarını ve "
        "dosyalarını göreceğini bu belirler. Kendi skill'lerin ve servislerin "
        "hangi dizin olursa olsun oradadır.",
    "Give up after": "Şu süreden sonra vazgeç",
    "A command still running after this is given up on. The tray menu can stop "
    "one earlier.":
        "Bu süreden sonra hâlâ süren komuttan vazgeçilir. Tepsi menüsünden daha "
        "erken de durdurulabilir.",
    "Carry on for": "Şu kadar süre sürsün",
    "every command on its own": "her komut ayrı",
    "Commands within this long of each other are one conversation, so “and move "
    "that to Thursday” knows what “that” is. After it, the next command starts "
    "fresh.":
        "Birbirinden bu kadar süre içinde gelen komutlar tek bir konuşmadır; "
        "böylece “onu perşembeye al” dediğinde “o”nun ne olduğu bilinir. Bu "
        "sürenin ardından bir sonraki komut sıfırdan başlar.",
    "No conversation going.": "Süren bir konuşma yok.",
    "Last used {minutes} min ago.": "En son {minutes} dk önce kullanıldı.",
    "Paste it into the focused window": "Odaktaki pencereye yapıştır",
    "It is copied to the clipboard either way.": "Panoya her hâlükârda kopyalanır.",
    "Clean the transcript up before sending it": "Göndermeden önce transkripti temizle",
    "Off by default: Claude reads through “erm” and “you know” without help, "
    "and cleanup costs an API call and a second or two.":
        "Varsayılan olarak kapalı: Claude “eee” ve “hani”yi yardımsız da okur, "
        "temizlik ise bir API çağrısına ve bir iki saniyeye mal olur.",
    "Told to the assistant alongside every command, on top of whatever your "
    "own configuration already says.":
        "Her komutla birlikte asistana söylenir, kendi yapılandırmanın zaten "
        "söylediklerinin üstüne eklenir.",
    "  ·  asked {who}: {question}": "  ·  {who} soruldu: {question}",

    # --- meetings: tray and pipeline ---------------------------------------
    "Record a meeting": "Toplantı kaydet",
    "End the meeting and write it up": "Toplantıyı bitir ve tutanağı çıkar",
    "Writing the meeting up…": "Tutanak çıkarılıyor…",
    "Discard the meeting": "Toplantıyı iptal et",
    "Ending the meeting…": "Toplantı bitiriliyor…",
    "Dikte: in a meeting": "Dikte: toplantıda",
    "Dikte: in a meeting ({time})": "Dikte: toplantıda ({time})",
    "Dikte: writing the meeting up": "Dikte: tutanak çıkarıyor",
    "Meeting recorded, writing it up…": "Toplantı kaydedildi, tutanak çıkarılıyor…",
    "Meeting written up: {title}": "Tutanak hazır: {title}",
    "Dikte: the meeting is written up": "Dikte: tutanak hazır",
    "Meeting failed: {error}": "Toplantı başarısız: {error}",
    "Dikte: the meeting could not be written up": "Dikte: tutanak çıkarılamadı",
    "{error}\n\nThe recording has been kept. Settings → Minutes can try again.":
        "{error}\n\nSes kaydı duruyor. Ayarlar → Tutanaklar üzerinden yeniden "
        "denenebilir.",
    "Recording saved. The previous meeting is still being written up, so start "
    "this one from Settings → Minutes when it is done.":
        "Kayıt saklandı. Önceki toplantının tutanağı hâlâ çıkarılıyor; bu kaydı o "
        "bitince Ayarlar → Tutanaklar üzerinden başlat.",
    "The recording stopped on its own; the sound device may have gone away. "
    "Keeping what was captured.":
        "Kayıt kendiliğinden durdu, ses aygıtı çekilmiş olabilir. O ana kadar "
        "kaydedilen saklanıyor.",
    "ffmpeg not found. Install it to record a meeting.":
        "ffmpeg bulunamadı. Toplantı kaydı için kur.",
    "Could not work out which speaker output to record. Pick one in "
    "Settings → Meeting.":
        "Hangi ses çıkışının kaydedileceği anlaşılamadı. Ayarlar → Toplantı "
        "sekmesinden seç.",
    "Nothing was recorded: {error}": "Hiçbir şey kaydedilmedi: {error}",
    "The saved macOS audio device uses an old numeric index. Open Settings and "
    "select the device again before recording.":
        "Kayıtlı macOS ses aygıtı eski bir sayısal indeks kullanıyor. Kayıttan "
        "önce Ayarlar'ı açıp aygıtı yeniden seç.",
    "The saved macOS audio device is no longer connected: {device}. Open "
    "Settings and select another device.":
        "Kayıtlı macOS ses aygıtı artık bağlı değil: {device}. Ayarlar'ı açıp "
        "başka bir aygıt seç.",
    "More than one macOS audio device is named {device}. Disconnect the "
    "duplicate or choose a different device.":
        "Birden fazla macOS ses aygıtının adı {device}. Aynı adlı aygıtlardan "
        "birini çıkar ya da başka bir aygıt seç.",
    "The microphone handed over almost nothing ({percent}% of the recording was "
    "empty), so your own side of the meeting will be mostly missing. Check the "
    "device before the next one.":
        "Mikrofon neredeyse hiçbir şey iletmedi (kaydın %{percent} kadarı boştu), "
        "toplantının senin tarafın büyük ölçüde eksik olacak. Bir sonrakinden "
        "önce aygıtı kontrol et.",
    "Transcribing {side}: {index}/{count}…":
        "{side} yazıya çevriliyor: {index}/{count}…",
    "you": "sen",
    "the others": "karşı taraf",
    "Cleaning up {index}/{count}…": "Temizleniyor {index}/{count}…",
    "Writing the minutes…": "Tutanak yazılıyor…",
    "Neither side of the recording had any speech in it.":
        "Kaydın iki tarafında da konuşma yok.",
    "This recording is not a two-channel meeting.":
        "Bu kayıt iki kanallı bir toplantı kaydı değil.",
    "The recording is gone: {path}": "Ses kaydı yerinde yok: {path}",
    "Meeting": "Toplantı",
    "Transcript": "Transkript",
    "{minutes} min": "{minutes} dk",
    "{hours} h {minutes} min": "{hours} sa {minutes} dk",

    # --- settings: meeting --------------------------------------------------
    "Minutes": "Tutanaklar",
    "Sound": "Ses",
    "Same as dictation": "Diktedekiyle aynı",
    "Current output": "Geçerli çıkış",
    "The other participants": "Karşı tarafın sesi",
    "macOS does not offer what the speakers are playing as something to "
    "record. Install BlackHole or Loopback, send the meeting's sound through "
    "it, and pick it above.":
        "macOS, hoparlörden çıkan sesi kaydedilebilir bir kaynak olarak sunmaz. "
        "BlackHole ya da Loopback kur, toplantının sesini oradan geçir ve "
        "yukarıdan onu seç.",
    "This system offers nothing that records what the speakers are playing, "
    "so a meeting cannot be recorded on it. Dictation and transcribing a file "
    "are unaffected.":
        "Bu sistem, hoparlörden çıkan sesi kaydeden hiçbir şey sunmuyor; "
        "burada toplantı kaydedilemez. Dikte ve dosya deşifresi bundan "
        "etkilenmez.",
    "This system offers nothing that records what the speakers are playing, "
    "so a meeting cannot be recorded on it.":
        "Bu sistem, hoparlörden çıkan sesi kaydeden hiçbir şey sunmuyor; "
        "burada toplantı kaydedilemez.",
    "Wear headphones if you can. Through speakers your microphone hears the "
    "other side as well, and although a line that lands on both channels at "
    "once is dropped again, the repair is never as clean as not needing it.":
        "Yapabiliyorsan kulaklık tak. Hoparlörde mikrofonun karşı tarafı da "
        "duyar; aynı anda iki kanala birden düşen satır ayıklanıyor ama bu "
        "onarım, hiç gerekmemesi kadar temiz olmuyor.",
    "Who is talking": "Kimler konuşuyor",
    "Me": "Ben",
    "Other side": "Karşı taraf",
    "You": "Sen",
    "The other end": "Karşı taraf",
    "Expected": "Beklenen kişiler",
    "One name per line": "Her satıra bir isim",
    "Everyone on the far end shares one label: they reach you as a single mixed "
    "signal. The names go to the transcription model so they come out spelled "
    "right, and to the minutes, which may use one for a line only when the "
    "conversation itself makes clear who was speaking.":
        "Karşı taraftaki herkes tek bir etiketi paylaşır; sana tek bir karışım "
        "olarak gelirler. İsimler, doğru yazılsınlar diye transkripsiyon modeline "
        "ve tutanağa gider; tutanak bir satıra ancak konuşmanın kendisi kimin "
        "konuştuğunu açık ediyorsa isim yazar.",
    "Unlike cleanup, this one is worth some thinking: it has to hold a whole "
    "meeting in its head and work out what was actually decided.":
        "Temizlemenin aksine burada düşünmenin karşılığı var: model bütün "
        "toplantıyı aklında tutup neyin gerçekten karara bağlandığını çıkarmak "
        "zorunda.",
    "Clean the transcript up first": "Önce transkripti temizle",
    "Runs the cleanup model over the transcript before the minutes are written, "
    "keeping the timestamps and the speaker labels.":
        "Tutanak yazılmadan önce transkripti temizleme modelinden geçirir; zaman "
        "damgaları ve konuşmacı etiketleri korunur.",
    "Recording": "Kayıt",
    " min": " dk",
    "Longest meeting": "En uzun toplantı",
    "Keep the recording after the minutes are written":
        "Tutanak çıktıktan sonra ses kaydını sakla",
    "A run that fails keeps its recording either way, so it can be tried again "
    "from the Minutes tab. This is about the ones that worked.":
        "Başarısız olan bir işlemin kaydı zaten saklanır, Tutanaklar sekmesinden "
        "yeniden denenebilsin diye. Buradaki ayar başarıyla bitenler için.",
    "none": "yok",
    "Type a key combination first.": "Önce bir tuş kombinasyonu yaz.",
    "No KDE shortcut installed. The tray menu starts a meeting too.":
        "KDE kısayolu kurulu değil. Toplantıyı tepsi menüsünden de başlatabilirsin.",
    "System instruction given to the minutes model.":
        "Tutanak modeline verilen sistem talimatı.",
    "Pick a meeting to read it.": "Okumak için bir toplantı seç.",
    "Write it up": "Tutanağı çıkar",
    "Open the folder": "Klasörü aç",
    "waiting to be written up": "tutanak bekliyor",
    "transcript ready, minutes missing": "transkript hazır, tutanak eksik",
    "failed": "başarısız",
    "Nothing has been written yet.": "Henüz bir şey yazılmadı.",
    "Done: {title}": "Bitti: {title}",
    "This one is being written up right now.": "Bunun tutanağı şu anda çıkarılıyor.",
    "Delete this meeting, its minutes and its recording?":
        "Bu toplantı, tutanağı ve ses kaydı silinsin mi?",

    # --- local models and downloads ------------------------------------
    # The whole box was born after the last translation pass, which left the
    # first-run screen half English on a Turkish machine.
    "Download": "İndir",
    "Delete": "Sil",
    "Program": "Program",
    "Publisher": "Yayıncı",
    "Automatic": "Otomatik",
    "Threads": "İş parçacığı",
    "On this machine": "Bu makinede",
    "Use the graphics card": "Ekran kartını kullan",
    "Load the model when Dikte starts": "Modeli Dikte açılırken yükle",
    "Models on this machine": "Bu makinedeki modeller",
    "Unload a model that is sitting unused": "Kullanılmayan modeli bellekten çıkar",
    "A loaded model holds its memory whether anything is using it or "
    "not: over a gigabyte for whisper, several for an LLM. Unloading "
    "gives that back to the rest of the desktop, and the next "
    "dictation loads it again at the cost of the seconds that takes.":
        "Yüklü bir model, kullanılsa da kullanılmasa da belleği tutar: whisper "
        "için bir gigabaytın üzerinde, bir LLM için birkaç gigabayt. Bellekten "
        "çıkarmak bunu masaüstünün geri kalanına iade eder, sonraki dikte de "
        "modeli birkaç saniye bekleyerek yeniden yükler.",
    " minute": " dakika",
    " minutes": " dakika",
    "After": "Şu kadar sonra",
    "Unload the model": "Modeli bellekten çıkar",
    "Unload the models": "Modelleri bellekten çıkar",
    "No model loaded": "Yüklü model yok",
    "A model is loading or answering right now. Try again in a "
    "moment.":
        "Bir model şu anda yükleniyor ya da cevap veriyor. Az sonra tekrar "
        "deneyin.",
    "Local whisper": "Yerel whisper",
    "Local model": "Yerel model",
    "Model folder": "Model klasörü",
    "The folder shared by the local whisper and llama models. Choose "
    "an ASCII-only path on Windows if your user folder contains "
    "characters whisper.cpp cannot open. Empty uses the default.":
        "Yerel whisper ve llama modellerinin ortak klasörü. Windows kullanıcı "
        "klasörünüzde whisper.cpp'nin açamadığı karakterler varsa yalnızca ASCII "
        "karakterlerden oluşan bir yol seçin. Boş bırakılırsa varsayılan kullanılır.",
    "Not loaded.": "Yüklü değil.",
    "Loaded; it did not say what it is running on.":
        "Yüklendi; neyin üzerinde çalıştığını söylemedi.",
    "Loaded on the graphics card ({detail}).":
        "Ekran kartına yüklendi ({detail}).",
    "Loaded on the processor ({detail}).": "İşlemciye yüklendi ({detail}).",
    "Loaded on the processor: only the CPU backend was loaded. Check the "
    "server log for graphics backend or driver errors.":
        "İşlemciye yüklendi: yalnızca CPU arka ucu yüklendi. Ekran kartı arka "
        "ucu veya sürücü hataları için sunucu günlüğünü kontrol edin.",
    "Loaded on the processor: the graphics card is switched on, but could not "
    "be used.":
        "İşlemciye yüklendi: ekran kartı açık, ama kullanılamadı.",
    "Not installed.": "Kurulu değil.",
    "Installed on the system: {path}": "Sistemde kurulu: {path}",
    "Using custom build: {path}": "Özel derleme kullanılıyor: {path}",
    "Download again": "Yeniden indir",
    "Downloaded, version {version}.": "İndirildi, sürüm {version}.",
    "Downloaded, version {version}. There was no Vulkan build, "
    "so this one runs on the processor.":
        "İndirildi, sürüm {version}. Vulkan sürümü yoktu, bu sürüm işlemcide çalışıyor.",
    "Fetching the model list…": "Model listesi çekiliyor…",
    "Downloading…": "İndiriliyor…",
    "Starting the download…": "İndirme başlatılıyor…",
    "Downloading: {done} of {total}{share}": "İndiriliyor: {done} / {total}{share}",
    "Download stopped.": "İndirme durduruldu.",
    "Ready: {name}.": "Hazır: {name}.",
    "Nothing downloaded yet.": "Henüz bir şey indirilmedi.",
    "{name} has not been downloaded yet.": "{name} henüz indirilmedi.",
    "{name} is here, but the program above is not. Download it first.":
        "{name} burada, ama yukarıdaki program değil. Önce onu indirin.",
    "{name} is not on this machine and this publisher does not offer it. "
    "Choose another model, or another publisher.":
        "{name} bu makinede yok ve bu yayıncı da sunmuyor. Başka bir model, "
        "ya da başka bir yayıncı seçin.",
    "downloaded": "indirildi",
    "not downloaded": "indirilmedi",
    "recommended": "önerilen",
    "{bits}-bit": "{bits} bit",
    "English only": "yalnızca İngilizce",
    "All": "Tümü",
    "Everything ggml-org publishes, including the models that are too big to "
    "run here and the ones that are not for cleaning up text.":
        "ggml-org'un yayımladığı her şey; burada çalıştırılamayacak kadar "
        "büyük olanlar ve metin temizlemek için olmayanlar dahil.",
    "Google Gemma 4, the small one. The default: nothing else this size "
    "follows an instruction as closely, and cleanup is all instruction.":
        "Google Gemma 4'ün küçüğü. Varsayılan: bu boyutta verilen yönergeyi "
        "bu kadar iyi izleyen başka bir model yok, temizleme de baştan sona "
        "yönerge demek.",
    "The same model one size up. A little more accurate, about twice the "
    "weights and twice the wait.":
        "Aynı modelin bir boy büyüğü. Biraz daha isabetli, yaklaşık iki katı "
        "ağırlık ve iki katı bekleyiş.",
    "The previous Gemma. Still good, and the smallest of the Gemmas here.":
        "Bir önceki Gemma. Hâlâ iyi ve buradaki Gemma'ların en küçüğü.",
    "Hugging Face's own small model, for a machine the Gemmas crowd.":
        "Hugging Face'in kendi küçük modeli; Gemma'ların sıkıştırdığı bir "
        "makine için.",
    "The smallest of them, for a machine nothing else fits on. It thinks "
    "before it answers unless Thinking below is off.":
        "En küçükleri; başka hiçbir şeyin sığmadığı bir makine için. "
        "Aşağıdaki Düşünme kapalı değilse cevaplamadan önce düşünür.",
    "too big for this machine": "bu makine için fazla büyük",
    "This machine": "Bu makine",
    "Graphics: {name}.": "Ekran kartı: {name}.",
    "No graphics interface found, so this runs on the processor.":
        "Ekran kartı arayüzü bulunamadı, bu yüzden işlemcide çalışıyor.",
    "Memory: {size}.": "Bellek: {size}.",
    "A model may take half of this memory, less a gigabyte for the context "
    "around the weights. Anything past that is marked too big; it may still "
    "load, on a machine with nothing else open.":
        "Bir model bu belleğin yarısını, ağırlıkların çevresindeki bağlam için "
        "bir gigabayt düşülerek kullanabilir. Bunu aşan modeller fazla büyük "
        "diye işaretlenir; başka hiçbir şeyin açık olmadığı bir makinede yine "
        "de yüklenebilirler.",
    "Recommended for this machine": "Bu makine için önerilen",
    "Everything this publisher offers": "Bu yayıncının sunduğu her şey",
    "Already on this machine": "Bu makinede zaten var",
    "Chosen, but not downloaded": "Seçili, ama indirilmedi",
    "{repo} publishes nothing that can be run here. Its models are split "
    "across files, larger than {cap}, or pieces of a model rather than one. "
    "Choose another publisher.":
        "{repo} burada çalıştırılabilecek bir şey yayımlamıyor. Modelleri "
        "birden çok dosyaya bölünmüş, {cap} boyutundan büyük ya da modelin "
        "kendisi değil parçaları. Başka bir yayıncı seçin.",
    "large-v3 makes the fewest mistakes and is the slowest of them. "
    "large-v3-turbo is that model with a four layer decoder in place of a "
    "thirty-two layer one: several times faster, at one to two points of word "
    "error in English and about two and a half in the other languages. Below "
    "those, every step down the list trades accuracy for size, and the .en "
    "models are trained on English alone.":
        "En az hatayı large-v3 yapar, en yavaşı da odur. large-v3-turbo, aynı "
        "modelin otuz iki katmanlı çözücüsü yerine dört katmanlı bir çözücü "
        "konmuş hâli: birkaç kat hızlı, karşılığında İngilizcede bir iki "
        "puan, diğer dillerde yaklaşık iki buçuk puan kelime hatası. Bunların "
        "altında listede her basamak, doğruluğu boyuta değişir; .en modelleri "
        "ise yalnızca İngilizce ile eğitilmiştir.",
    "Cleanup is punctuation, capitals and filler words, so what these are "
    "picked on is following an instruction rather than knowing anything. "
    "Start at a q4 file; the 16-bit ones are several times the memory for a "
    "difference this job cannot see.":
        "Temizleme; noktalama, büyük harf ve dolgu sözcükleri demek, yani bu "
        "modeller bir şey bilmelerine değil verilen yönergeyi izlemelerine "
        "göre seçilir. Bir q4 dosyasından başlayın; 16 bitlik olanlar, bu işin "
        "göremeyeceği bir fark için kat kat bellek ister.",
    "Delete model": "Modeli sil",
    "Delete {name} from this machine?": "{name} bu makineden silinsin mi?",
    "Runs on this machine, on llama.cpp.": "Bu makinede, llama.cpp üzerinde çalışır.",
    "A Hugging Face repository of GGUF files. The list is fetched; any other "
    "one can be typed in.":
        "GGUF dosyaları içeren bir Hugging Face deposu. Liste internetten "
        "çekilir; başka bir depo da yazılabilir.",
    "A large model takes a second or two to load. Loading it up front spends "
    "that once instead of on the first dictation, at the cost of the memory "
    "it sits in.":
        "Büyük bir modelin yüklenmesi bir iki saniye sürer. Baştan yüklemek bu "
        "bedeli ilk diktede değil bir kez öder; karşılığı, modelin oturduğu "
        "bellektir.",
    "An LLM is slower to load than a whisper model and sits in more memory. "
    "Off means it is loaded on the first cleanup instead.":
        "Bir LLM, whisper modelinden daha geç yüklenir ve daha çok bellekte "
        "oturur. Kapalı, ilk temizlemede yüklenmesi demektir.",
    "A model trained to think will think unless it is told not to, and "
    "spending 300 tokens of reasoning on a comma is 300 tokens of waiting. "
    "Off is what cleanup wants.":
        "Düşünmeye eğitilmiş bir model, aksi söylenmedikçe düşünür; bir virgül "
        "için 300 token akıl yürütmek 300 token'lık bekleyiştir. Temizleme için "
        "doğrusu Kapalı.",
    "whisper.cpp reaches the card through CUDA, ROCm or Vulkan when the build "
    "it is running was made with one. A build without any of them runs on the "
    "processor whatever this says.":
        "whisper.cpp karta CUDA, ROCm ya da Vulkan üzerinden ulaşır; koştuğu "
        "derleme bunlardan biriyle yapılmışsa. Hiçbiri olmadan derlenmiş bir "
        "kopya, bu ne derse desin işlemcide çalışır.",
    "whisper.cpp is not installed. Settings → API and models → Download.":
        "whisper.cpp kurulu değil. Ayarlar → API ve modeller → İndir.",
    "llama.cpp is not installed. Settings → API and models → Download.":
        "llama.cpp kurulu değil. Ayarlar → API ve modeller → İndir.",
    "No whisper model has been downloaded yet. Settings → API and models → "
    "Download.":
        "Henüz whisper modeli indirilmedi. Ayarlar → API ve modeller → İndir.",
    "No local cleanup model has been downloaded yet. Settings → API and "
    "models → Download.":
        "Henüz yerel temizleme modeli indirilmedi. Ayarlar → API ve modeller "
        "→ İndir.",
    "Hugging Face did not return a model list.":
        "Hugging Face model listesi döndürmedi.",
    "{repo} did not return a file list.": "{repo} dosya listesi döndürmedi.",
    "{repo} has no downloadable release.":
        "{repo} deposunun indirilebilir bir sürümü yok.",
    "{repo} {tag} has no build for this machine.":
        "{repo} {tag} bu makine için derleme içermiyor.",
    "{url} answered HTTP {code}.": "{url} HTTP {code} yanıtı verdi.",
    "Could not reach {url}: {error}": "{url} adresine ulaşılamadı: {error}",
    "Could not read the answer from {url}: {error}":
        "{url} yanıtı okunamadı: {error}",
    "Could not create {path}: {error}": "{path} oluşturulamadı: {error}",
    "Could not download {name}: HTTP {code}":
        "{name} indirilemedi: HTTP {code}",
    "Could not download {name}: {error}": "{name} indirilemedi: {error}",
    "Could not write {name}: {error}": "{name} yazılamadı: {error}",
    "Could not unpack {name}: {error}": "{name} açılamadı: {error}",
    "Could not install {name}: {error}": "{name} kurulamadı: {error}",
    "Could not start {name}: {error}": "{name} başlatılamadı: {error}",
    "Could not delete the model: {error}": "Model silinemedi: {error}",
    "Could not replace {path}: a file in it is still open: {error}":
        "{path} değiştirilemedi: içindeki bir dosya hâlâ açık: {error}",
    "{name} did not start: {error}": "{name} başlamadı: {error}",
    "no output": "çıktı yok",
    "The download stopped early ({done} of {total}).":
        "İndirme erken kesildi ({done} / {total}).",
    "{name} is longer than it said it would be.":
        "{name} bildirdiğinden daha uzun çıktı.",
    "{name} does not match its published checksum. Nothing was installed.":
        "{name} yayımlanan sağlama toplamıyla uyuşmuyor. Hiçbir şey kurulmadı.",
    "{name} is published without a checksum, so there is no way to tell what "
    "arrived. Nothing was installed.":
        "{name} sağlama toplamı olmadan yayımlanmış; gelenin ne olduğu "
        "doğrulanamaz. Hiçbir şey kurulmadı.",
    "{name} was not in the download.": "{name} indirilenin içinde yoktu.",
    "{name} downloaded, but the old file is held open by the running server. "
    "Stop it and try again.":
        "{name} indirildi ama eski dosyayı çalışan sunucu açık tutuyor. "
        "Sunucuyu durdurup yeniden dene.",
    "The cleanup model spent its whole reply on thinking. Set Thinking to "
    "“Off”.":
        "Temizleme modeli bütün yanıtını düşünmeye harcadı. Düşünme'yi "
        "“Kapalı” yap.",
    "The cleanup model was cut off before it finished.":
        "Temizleme modeli bitiremeden kesildi.",
    "The model was cut off before it finished.":
        "Model bitiremeden kesildi.",

    # --- this pass's new messages ---------------------------------------
    "Audio recorder stopped before receiving sound":
        "Ses kayıt aracı veri alamadan kapandı",
    "Could not write the recording: {error}": "Kayıt dosyası yazılamadı: {error}",
    "Copied, but pasting failed: {error}":
        "Kopyalandı ama yapıştırma başarısız: {error}",
    "The recording was kept: {path}": "Kayıt saklandı: {path}",
    "The recording stopped on its own; transcribing what was captured.":
        "Kayıt kendi kendine durdu; yakalanan kısım yazıya dökülüyor.",
    "Could not save the settings: {error}": "Ayarlar kaydedilemedi: {error}",
    "The provider returned an invalid model catalog.": "Sağlayıcı geçersiz bir model listesi döndürdü.",
    # Local processing and verified device selection.
    "A specific graphics card can only be selected with Dikte's managed Vulkan program. Choose Automatic or Processor in Settings.": "Belirli bir ekran kartı yalnızca Dikte'nin yönettiği Vulkan programıyla seçilebilir. Ayarlar'dan Otomatik veya İşlemci'yi seç.",
    "Advanced": "Gelişmiş",
    "Automatic (whisper.cpp default)": "Otomatik (whisper.cpp varsayılanı)",
    "Automatic lets whisper.cpp choose a graphics card through Metal, CUDA, ROCm or Vulkan when its build supports one. Processor keeps all speech recognition on the CPU.": "Otomatik seçeneği, kullanılan derleme destekliyorsa Metal, CUDA, ROCm veya Vulkan üzerinden bir ekran kartını whisper.cpp'nin seçmesini sağlar. İşlemci seçeneğinde tüm konuşma tanıma işlemi CPU üzerinde yapılır.",
    "CPU threads": "İşlemci iş parçacıkları",
    "CPU-thread limit available to this process: {count}. Automatic lets whisper.cpp choose. More threads are not always faster.": "Bu işlem için kullanılabilir iş parçacığı sınırı: {count}. Otomatik seçeneğinde sayıyı whisper.cpp belirler. Daha fazla iş parçacığı her zaman daha hızlı değildir.",
    "Custom program unavailable: {path}": "Özel program kullanılamıyor: {path}",
    "Detected graphics: {devices}. {reason} Automatic may still use a graphics card if the program supports it.": "Algılanan ekran kartları: {devices}. {reason} Program destekliyorsa Otomatik seçeneği yine de ekran kartı kullanabilir.",
    "Download failed: {error}": "İndirme başarısız: {error}",
    "Downloaded: {name}, version {version}.": "İndirildi: {name}, sürüm {version}.",
    "Downloaded: {name}, version {version}. There was no Vulkan build, so this one runs on the processor.": "İndirildi: {name}, sürüm {version}. Vulkan derlemesi bulunamadığı için bu sürüm işlemci üzerinde çalışır.",
    "GGML_VK_VISIBLE_DEVICES overrides graphics visibility.": "GGML_VK_VISIBLE_DEVICES, hangi ekran kartlarının görüneceğini belirliyor.",
    "Graphics: Processor only.": "Grafik işlem: Yalnızca işlemci.",
    "Graphics: {devices}.": "Ekran kartları: {devices}.",
    "Memory: {memory}.": "Bellek: {memory}.",
    "Previously selected graphics card (unavailable)": "Önceden seçilen ekran kartı (kullanılamıyor)",
    "Processing device": "İşlem aygıtı",
    "Processor (CPU)": "İşlemci (CPU)",
    "Selected: Automatic.": "Seçili: Otomatik.",
    "Selected: Graphics card unavailable.": "Seçili: Ekran kartı kullanılamıyor.",
    "Selected: Processor (CPU).": "Seçili: İşlemci (CPU).",
    "Selected: {name}.": "Seçili: {name}.",
    "The program's graphics device mapping could not be verified.": "Programın ekran kartı eşlemesi doğrulanamadı.",
    "This whisper.cpp build has no graphics card support, so it always runs on the processor.": "Bu whisper.cpp derlemesinde ekran kartı desteği yok, bu yüzden her zaman işlemcide çalışır.",
    "The saved processing device is invalid. Choose a device in Settings.": "Kayıtlı işlem aygıtı geçersiz. Ayarlar'dan bir aygıt seç.",
    "The selected custom or unmanaged program does not provide verified explicit graphics selection.": "Seçilen özel veya Dikte'nin yönetmediği program, doğrulanmış ekran kartı seçimini desteklemiyor.",
    "The selected graphics card is not available. Choose another processing device in Settings.": "Seçilen ekran kartı kullanılamıyor. Ayarlar'dan başka bir işlem aygıtı seç.",
    "Use automatic selection": "Otomatik seçimi kullan",
    "dedicated": "ayrılmış",
    "shared": "paylaşımlı",
    "{name} ({size} {kind})": "{name} ({size} {kind})",
    "{size} system": "{size} sistem belleği",
    "{size} {kind} graphics": "{size} {kind} ekran kartı belleği",

    # Asking about selected text.
    "Selected text": "Seçili metin",
    "Ask about the selected text": "Seçili metin hakkında sor",
    "Select text, press the shortcut and say what to do with it. The answer "
    "opens in a window; nothing is pasted until you press Replace selection. "
    "The selection goes to the assistant with no tools, and Codex and "
    "Antigravity are not sent it. The history keeps your instruction and the "
    "reply, not the selection.":
        "Metni seç, kısayola bas ve onunla ne yapılacağını söyle. Cevap bir "
        "pencerede açılır; Seçimi değiştir'e basmadan hiçbir şey yapıştırılmaz. "
        "Seçim asistana araçsız gönderilir; Codex ve Antigravity'ye hiç "
        "gönderilmez. Geçmişte seçim değil, talimatın ve cevap saklanır.",
    "The clipboard was left alone, so no selection was read.":
        "Panoya dokunulmadı, bu yüzden seçim okunmadı.",
    "The selection was not shown in time, so it was not sent.":
        "Seçim zamanında gösterilemedi, bu yüzden gönderilmedi.",
    "Nothing was pasted. Use Copy instead.":
        "Hiçbir şey yapıştırılmadı. Bunun yerine kopyalamayı kullan.",
    "The clipboard holds an image, files or a password, which could not be "
    "put back as they were.":
        "Panoda bir resim, dosya ya da parola var ve bunlar olduğu gibi geri "
        "konamazdı.",
    "{tool} is needed to check the clipboard.":
        "Panoyu denetlemek için {tool} gerekiyor.",
    "The clipboard could not be read just now. Try again in a moment.":
        "Pano şu an okunamadı. Birazdan yeniden dene.",
    "{name} cannot run without tools, so selected text is not sent to it. "
    "Use Claude Code or a chat provider.":
        "{name} araçsız çalıştırılamadığı için seçili metin ona gönderilmez. "
        "Claude Code'u ya da bir sohbet sağlayıcısını kullan.",
    "Dikte: {name}": "Dikte: {name}",
    "You said: {text}": "Söylediğin: {text}",
    "About the selection ({count} characters): {preview}":
        "Seçim hakkında ({count} karakter): {preview}",
    "Selected ({count} characters): {preview}": "Seçili ({count} karakter): {preview}",
    "Nothing selected": "Seçili metin yok",
    "This assistant does not read the selection.": "Bu asistan seçili metni okumaz.",
    "Apply": "Uygula",
    "Replaces the selected text in the window it came from. Nothing is pasted "
    "until you press this.":
        "Seçili metni geldiği pencerede değiştirir. Buna basmadan hiçbir şey "
        "yapıştırılmaz.",
    "Cancel": "Vazgeç",
    "Closes this and leaves the original text alone.":
        "Pencereyi kapatır, asıl metne dokunmaz.",
    "Copy failed": "Kopyalanamadı",


    # Writing profiles, translation and the personal dictionary.
    "Default": "Varsayılan",
    "Profiles": "Profiller",
    "Copy original": "Orijinali kopyala",
    "Enter or a double click copies the entry; Ctrl+C copies the selection. The context menu has the other actions.":
        "Enter ya da çift tıklama kaydı kopyalar; Ctrl+C seçimi kopyalar. Diğer işlemler sağ tık menüsünde.",
    "Copy the transcript as it was heard, before it was translated.": "Transkripti çevrilmeden önce, duyulduğu haliyle kopyala.",
    "  ·  profile: {name}": "  ·  profil: {name}",
    "  ·  translated into {language}": "  ·  çeviri: {language}",
    "  ·  translation into {language} failed": "  ·  {language} çevirisi başarısız",
    "Your own instruction replaces the built-in one. The dictionary, and the style and translation of the profile in use, are still added after it. Switch the profile style off under Profiles to use your instruction alone.": "Kendi talimatın yerleşik talimatın yerine geçer. Sözlük ile kullanılan profilin üslubu ve çevirisi yine de arkasına eklenir. Talimatını tek başına kullanmak için Profiller altında profil üslubunu kapat.",
    "Could not save the dictionary: {error}": "Sözlük kaydedilemedi: {error}",
    "Translating into {language}…": "{language} diline çevriliyor…",
    "Cleaning up ({profile})…": "Temizleniyor ({profile})…",
    "Translation failed, so the original transcript was copied and not pasted: {error}": "Çeviri başarısız oldu; orijinal transkript kopyalandı ama yapıştırılmadı: {error}",
    "The program in front is looked up when a recording starts. When it cannot be found out or no profile lists it, the Default profile is used, and the history names the profile and the program.": "Kayıt başladığında öndeki program bulunur. Bulunamazsa ya da hiçbir profil onu listelemiyorsa Varsayılan profil kullanılır; geçmiş, kullanılan profili ve programı yazar.",
    " ({program})": " ({program})",
    " (program unknown)": " (program bilinmiyor)",
    "Dictionary entry": "Sözlük kaydı",
    "e.g. dikte": "örn. dikte",
    "Optional, e.g. Dikte": "İsteğe bağlı, örn. Dikte",
    "Word or expression": "Kelime veya ifade",
    "Preferred spelling": "Tercih edilen yazım",
    "Search": "Ara",
    "Add…": "Ekle…",
    "Edit…": "Düzenle…",
    "Added": "Ekleyen",
    "Auto": "Otomatik",
    "Manual": "Elle",
    "Auto-added": "Otomatik eklenenler",
    "Manually added": "Elle eklenenler",
    "Clear auto-learned": "Otomatik öğrenilenleri temizle",
    "Learn names and terms from my dictations": "Diktelerimden isim ve terim öğren",
    "Only ordinary dictations are read, and only once they have been cleaned up and finished without a warning: never meetings, files, the assistant, translations, the clipboard or other programs. A name written with a capital in the middle of a sentence is added after it has come through three dictations unchanged, marked Auto. So is a misheard word the cleanup puts right the same way three times (Klod Kod to Claude Code), with what it was heard as. Until then what is being counted is kept in the dictionary file. A learned entry you delete is not learned again. The learning runs on this computer; what it adds is sent to the models with the rest of the dictionary.": "Yalnızca sıradan dikteler okunur, o da temizlendikten ve uyarısız bittikten sonra: toplantılar, dosyalar, asistan, çeviriler, pano ya da başka programlar asla okunmaz. Cümle ortasında büyük harfle yazılan bir isim, üç diktede değişmeden geçtikten sonra Otomatik işaretiyle eklenir. Temizlemenin üç kez aynı şekilde düzelttiği, yanlış duyulmuş bir kelime de (Klod Kod yerine Claude Code) nasıl duyulduğuyla birlikte öyle eklenir. O zamana kadar sayılanlar sözlük dosyasında tutulur. Öğrenilmiş bir kaydı silersen bir daha öğrenilmez. Öğrenme bu bilgisayarda yapılır; eklediği kayıtlar sözlüğün geri kalanıyla birlikte modellere gider.",
    "Names and terms you say often. They go to the transcription model as a hint, and to the cleanup model as a glossary, so it can repair the ones that still come out wrong. Every profile uses the same dictionary, and so do audio files and meetings.": "Sık söylediğin isimler ve terimler. Transkripsiyon modeline ipucu, temizleme modeline sözlük olarak gider; böylece yine yanlış çıkanları düzeltebilir. Bütün profiller aynı sözlüğü kullanır, ses dosyaları ve toplantılar da.",
    "Leave the spelling empty when the word is already written the way you want it. With one, the cleanup model is told to write the word that way.": "Kelime zaten istediğin gibi yazılıyorsa yazımı boş bırak. Doldurursan temizleme modeline kelimeyi böyle yazması söylenir.",
    "That word is already in the dictionary.": "Bu kelime sözlükte zaten var.",
    "What profiles may do": "Profillerin yapabilecekleri",
    "Apply the writing style of the profile": "Profilin yazım üslubunu uygula",
    "Adds the profile's preferences to the dictation cleanup instruction. A cleanup instruction of your own replaces the built-in one, and the style is still added after it; switch this off to use your own instruction alone.": "Profilin tercihlerini dikte temizleme talimatına ekler. Kendi temizleme talimatın yerleşik talimatın yerine geçer ve üslup yine de arkasına eklenir; kendi talimatını tek başına kullanmak için bunu kapat.",
    "Translate when the profile has a target language": "Profilde hedef dil varsa çevir",
    "The translation is made after the recording, by the cleanup model, before the text is pasted. It is not live. If it fails, the original transcript is copied and nothing is pasted.": "Çeviri kayıt bittikten sonra, metin yapıştırılmadan önce temizleme modeli tarafından yapılır. Canlı değildir. Başarısız olursa orijinal transkript kopyalanır ve hiçbir şey yapıştırılmaz.",
    "Profile for every dictation": "Bütün diktelerde kullanılacak profil",
    "Automatic, by the program in front": "Otomatik, öndeki programa göre",
    "Find the program name": "Program adını bul",
    "Switch to the program within three seconds; its name is shown here, ready to be listed in a profile.": "Üç saniye içinde programa geç; adı burada, bir profile yazılmaya hazır halde görünür.",
    "Switch to the program now…": "Şimdi programa geç…",
    "In front: {name}": "Öndeki: {name}",
    "The program in front could not be found out.": "Öndeki program bulunamadı.",
    "On GNOME, per-application profiles need the “Window Calls” GNOME Shell extension installed.": "GNOME'da uygulamaya göre profiller için “Window Calls” GNOME Shell eklentisi kurulu olmalı.",
    "On KDE Plasma under Wayland, per-application profiles need kdotool installed.": "Wayland altındaki KDE Plasma'da uygulamaya göre profiller için kdotool kurulu olmalı.",
    "On X11, per-application profiles need xprop installed.": "X11'de uygulamaya göre profiller için xprop kurulu olmalı.",
    "A profile says how a dictation should read, and can translate it. The Default profile is used unless a named profile lists the program in front when the recording starts. Files, meetings and the assistant are never changed by a profile.": "Profil, bir diktenin nasıl okunacağını belirler ve onu çevirebilir. Kayıt başladığında öndeki programı listeleyen adlı bir profil yoksa Varsayılan profil kullanılır. Dosyalar, toplantılar ve asistan hiçbir profilden etkilenmez.",
    "Add profile…": "Profil ekle…",
    "Add profile": "Profil ekle",
    "Rename…": "Yeniden adlandır…",
    "Rename profile": "Profili yeniden adlandır",
    "Name": "Ad",
    "A profile needs a name of its own.": "Profilin kendine ait bir adı olmalı.",
    "Programs": "Programlar",
    "e.g. thunderbird, outlook": "örn. thunderbird, outlook",
    "Program names, separated by commas, the way Find the program name shows them. A browser counts as one program whatever site is open in it.": "Program adları, virgülle ayrılmış ve Program adını bul'un gösterdiği gibi. Tarayıcı, içinde hangi site açık olursa olsun tek bir program sayılır.",
    "Formality": "Resmiyet",
    "Sentences": "Cümleler",
    "Punctuation": "Noktalama",
    "Brevity": "Kısalık",
    "Casual": "Samimi",
    "Neutral": "Nötr",
    "Formal": "Resmi",
    "Short": "Kısa",
    "Longer": "Daha uzun",
    "Light": "Hafif",
    "Expressive": "Duygulu",
    "Concise": "Öz",
    "Keep the full phrasing": "İfadeyi tam koru",
    "No preference": "Tercih yok",
    "e.g. Write numbers as digits": "örn. Sayıları rakamla yaz",
    "Also": "Ayrıca",
    "Do not translate": "Çevirme",
    "Translate into": "Şu dile çevir",
    "Reset learned style": "Öğrenilen üslubu sıfırla",
    "Learned from your examples: {preferences}": "Örneklerinden öğrenilen: {preferences}",
    "Learn the style from examples": "Üslubu örneklerden öğren",
    "Paste something you wrote, or a dictation and the way you corrected it. It is read on this computer and not kept: only the preferences found in it are, shown above, and a choice you made yourself always wins over a learned one.": "Yazdığın bir metni ya da bir dikteyi ve onu nasıl düzelttiğini yapıştır. Bu bilgisayarda okunur ve saklanmaz: yalnızca içinden çıkan tercihler saklanır ve yukarıda görünür. Kendi yaptığın bir seçim her zaman öğrenilenin önüne geçer.",
    "Examples of your own writing": "Kendi yazdığın örnekler",
    "What Dikte wrote (optional)": "Dikte'nin yazdığı (isteğe bağlı)",
    "What you corrected it to (optional)": "Senin düzelttiğin hali (isteğe bağlı)",
    "Learn from these": "Bunlardan öğren",
    "Learned: {preferences}": "Öğrenilen: {preferences}",
    "{name}: {value}": "{name}: {value}",
    "Italian": "İtalyanca",
    "Sites": "Siteler",
    "Names and terms you use; they help transcription and cleanup.": "Kullandığın isimler ve terimler; transkripsiyona ve temizlemeye yardım eder.",
    "Learns after three dictations, on this computer.": "Üç dikteden sonra, bu bilgisayarda öğrenir.",
    "A profile sets how dictation reads, and can translate it.": "Profil, diktenin nasıl okunacağını belirler ve onu çevirebilir.",
    "Automatic chooses by the program or site in front. A profile picked here is used for every dictation instead.": "Otomatik, öndeki programa ya da siteye göre seçer. Burada seçilen profil bunun yerine bütün diktelerde kullanılır.",
    "Paste your own writing; only the preferences found in it are kept.": "Kendi yazdığın bir metni yapıştır; yalnızca içinden çıkan tercihler saklanır.",
    "Per-application profiles are not available on this desktop.": "Uygulamaya göre profiller bu masaüstünde kullanılamıyor.",
    "Site matching is not available on macOS.": "Site eşleştirme macOS'ta kullanılamıyor.",
    "Matches the site's name in the browser tab's title.": "Tarayıcı sekmesinin başlığındaki site adıyla eşleşir.",
    "The profile changed meanwhile; nothing was added.": "Bu arada profil değişti; bir şey eklenmedi.",
    "{name} is not a browser Dikte knows.": "{name}, Dikte'nin tanıdığı bir tarayıcı değil.",
    "List it under Programs instead.": "Onu Programlar altına yaz.",
    "No site in the title; open the site's tab first.": "Başlıkta site yok; önce sitenin sekmesini aç.",
    "Read from {browser}.": "{browser} okundu.",
    "Read from {browser}: “{title}”. Double-click a site to change it.": "{browser} okundu: “{title}”. Değiştirmek için siteye çift tıkla.",
    "Added “{site}”.": "“{site}” eklendi.",
    "“{site}” is already listed.": "“{site}” zaten listede.",
    "Not enough to learn from; paste a few more sentences.": "Öğrenmek için yetersiz; birkaç cümle daha yapıştır.",
    "e.g. WhatsApp, Gmail, YouTube": "örn. WhatsApp, Gmail, YouTube",
    "Add": "Ekle",
    "Add site…": "Site ekle…",
    "Remove site": "Siteyi kaldır",
    "Counts down three seconds: switch to the browser tab in the meantime, and the site is read from its title.": "Üç saniye geri sayar: bu sırada tarayıcı sekmesine geç, site sekmenin başlığından okunur.",
    "Site matching is not available on macOS: reading another program's window title needs a permission Dikte does not ask for. Programs still match.": "Site eşleştirme macOS'ta kullanılamıyor: başka bir programın pencere başlığını okumak, Dikte'nin istemediği bir izin gerektiriyor. Programlar yine eşleşir.",
    "When a dictation starts in a browser, its window title is read once to match these sites. A site matches the site's name in the title, not the text of the page. Titles are never saved: the history keeps only the site that matched. A site wins over a program, so a browser listed above is used for every other site.": "Dikte bir tarayıcıda başladığında, bu sitelerle eşleştirmek için pencere başlığı bir kez okunur. Site, sayfanın metniyle değil, başlıktaki site adıyla eşleşir. Başlıklar asla kaydedilmez: geçmişte yalnızca eşleşen site tutulur. Site programın önüne geçer; yukarıda listelenen bir tarayıcı, diğer bütün siteler için kullanılır.",
    "Switch to the tab… {seconds}": "Sekmeye geç… {seconds}",
    "Reading the window in front…": "Öndeki pencere okunuyor…",
    "  ·  site: {site}": "  ·  site: {site}",
    "Portuguese": "Portekizce",
    "Dutch": "Felemenkçe",
    "Polish": "Lehçe",
    "Russian": "Rusça",
    "Ukrainian": "Ukraynaca",
    "Japanese": "Japonca",
    "Korean": "Korece",
    "Chinese": "Çince",

    # --- interface overhaul (sidebar, chips, list pages) --------------------
    "Replace selection": "Seçimi değiştir",
    "Close": "Kapat",
    "OK": "Tamam",
    "Models": "Modeller",
    "Editing": "Düzenleme",
    "Bottom left": "Sol alt",
    "Bottom right": "Sağ alt",
    "Top left": "Sol üst",
    "Top right": "Sağ üst",
    "Pause": "Duraklat",
    "Resume": "Devam et",
    "Discard": "At",
    "Open": "Aç",
    "More": "Diğer",
    "Reply": "Yanıt",
    "Key": "Anahtar",
    "{service} key": "{service} anahtarı",
    "{seconds} s": "{seconds} sn",
    "Stop and send": "Bitir ve gönder",
    "Stop and write up": "Bitir ve tutanağı yaz",
    "The transcript will appear here.": "Döküm burada görünecek.",
    "Records your microphone and the other side.":
        "Mikrofonunu ve karşı tarafı kaydeder.",
    "Connect OpenRouter in Settings to write minutes.":
        "Tutanak yazmak için Ayarlar'da OpenRouter'ı bağla.",
    "Needs BlackHole or Loopback on macOS.": "macOS'ta BlackHole ya da Loopback gerekir.",
    "Pick a transcription service and add its key, or use a model on this computer.":
        "Bir yazıya dökme hizmeti seçip anahtarını ekle ya da bu bilgisayardaki bir modeli kullan.",
    "A spoken command goes to the assistant. Its reply is copied without automatic pasting.":
        "Sesli komut asistana gider. Yanıtı otomatik yapıştırılmadan panoya kopyalanır.",
    "Dictation: {sound}": "Dikte: {sound}",
    "Cleanup: {text}": "Temizleme: {text}",
    "Shortcut: {shortcut}": "Kısayol: {shortcut}",
    "Permissions: {permission}": "İzinler: {permission}",
    "Working directory: {directory}": "Çalışma klasörü: {directory}",
    "Find…": "Bul…",
    "From tab…": "Sekmeden…",
    "Answers questions; runs no commands.": "Soruları yanıtlar; komut çalıştırmaz.",
    "A plain question and a plain answer, over the {service} key you already "
    "have. It runs no commands, opens no files and reaches none of your "
    "services, so it can tell you what the capital of Peru is but not what is "
    "in your calendar.":
        "Elindeki {service} anahtarıyla düz bir soru ve düz bir cevap. Komut "
        "çalıştırmaz, dosya açmaz, hizmetlerinin hiçbirine ulaşmaz; Peru'nun "
        "başkentini söyleyebilir ama takviminde ne olduğunu söyleyemez.",
    "Uses its own allow-rules for permissions.": "İzinler için kendi kurallarını kullanır.",
    "Antigravity has neither a permission mode nor a sandbox to hand it, so "
    "what it may do without asking is whatever its own allow-rules say. The "
    "working directory still applies.":
        "Antigravity'ye verilebilecek bir izin modu ya da korumalı alan yok; "
        "sormadan ne yapabileceğini kendi izin kuralları belirler. Çalışma "
        "klasörü yine de geçerlidir.",
    "Added to every command.": "Her komuta eklenir.",
    "Instructions": "Talimatlar",
    "Edit instructions": "Talimatları düzenle",
    "Using your own instructions.": "Kendi talimatların kullanılıyor.",
    "Using the built-in instructions.": "Yerleşik talimatlar kullanılıyor.",
    "How much the cleanup model may change your words.":
        "Temizleme modelinin sözlerini ne kadar değiştirebileceği.",
    "Keep the audio files": "Ses dosyalarını sakla",
    "Saved in {path}": "Kayıt yeri: {path}",
    "Pasting": "Yapıştırma",
    "Application": "Uygulama",
    "Appearance": "Görünüm",
    "Recording indicator": "Kayıt göstergesi",
    "Other connections": "Diğer bağlantılar",
    "Other connections ({count} set)": "Diğer bağlantılar ({count} ayarlı)",
    "{binary} was not found on your PATH.": "{binary} PATH üzerinde bulunamadı.",
    "Wear headphones if you can.": "Mümkünse kulaklık tak.",
    "Through speakers your microphone hears the other side as well, and "
    "although a line that lands on both channels at once is dropped again, "
    "the repair is never as clean as not needing it.":
        "Hoparlörden dinlerken mikrofonun karşı tarafı da duyar; iki kanala "
        "birden düşen satır yeniden atılsa da bu onarım, hiç gerekmemesi kadar "
        "temiz olmaz.",
    "Names help the spelling and the minutes.": "İsimler yazımı ve tutanağı iyileştirir.",
    "Meetings cannot be recorded on this system.": "Bu sistemde toplantı kaydedilemez.",
    "How shortcuts work here": "Kısayollar burada nasıl çalışır",
    "Use the built-in listener (/dev/input)": "Yerleşik dinleyiciyi kullan (/dev/input)",
    "For when the {desktop} shortcut is not active yet. Works immediately, no "
    "session restart. The only difference: the key combination also reaches "
    "the focused application.":
        "{desktop} kısayolu henüz etkin değilken işe yarar. Oturumu yeniden "
        "başlatmadan hemen çalışır. Tek fark, tuş kombinasyonu odaktaki "
        "uygulamaya da ulaşır.",
    "Installed shortcuts start working after you log in again.":
        "Kurulan kısayollar yeniden oturum açınca çalışmaya başlar.",
    "Dikte holds these combinations while it runs.": "Dikte bu kombinasyonları çalıştığı sürece tutar.",
    "Dikte listens for these combinations while it runs.": "Dikte bu kombinasyonları çalıştığı sürece dinler.",
    "Desktop command": "Masaüstü komutu",
    "Search the history": "Geçmişte ara",
    "Welcome to Dikte": "Dikte'ye hoş geldin",
    "Safe only": "Yalnızca güvenli",
    "All allowed": "Hepsine izin",
    "Workspace": "Çalışma alanı",
    "No sandbox": "Korumasız",
    "CLI rules": "CLI kuralları",
    "No commands": "Komut yok",

    # --- interface overhaul, second pass ------------------------------------
    "Not assigned.": "Atanmamış.",
    "Not registered with the desktop.": "Masaüstüne kayıtlı değil.",
    "Off until Ask about the selected text is on, under Assistant.":
        "Asistan sayfasında Seçili metin hakkında sor açılana kadar kapalı.",
    "Change in Shortcuts": "Kısayollar'da değiştir",
    "Spoken command": "Sesli komut",
    "Failed": "Başarısız",
    "into {language}": "{language} diline",
    "translation failed": "çeviri başarısız",
    "Antigravity": "Antigravity",
    "{name} ({width} × {height})": "{name} ({width} × {height})",
    "Try again": "Tekrar dene",
    "Record again": "Yeniden kaydet",
    "Check connection": "Bağlantıyı kontrol et",
    "Opens the Models page of the settings.": "Ayarların Modeller sayfasını açar.",
    "Transcription failed": "Yazıya dökme başarısız",
    "The recording was kept, so it can be tried again.":
        "Kayıt saklandı, yeniden denenebilir.",
    "Recording unavailable. Record it again, or check the connection if this "
    "keeps happening.":
        "Kayıt yok. Yeniden kaydet; tekrar ediyorsa bağlantıyı kontrol et.",
    "The recording was kept; select it and press Try again.":
        "Kayıt saklandı; seçip Tekrar dene'ye bas.",
    "Nothing from this publisher runs here. Choose another one.":
        "Bu yayıncının hiçbir modeli burada çalışmıyor. Başka birini seç.",
    "The program above is missing. Download it first.":
        "Yukarıdaki program yok. Önce onu indir.",
    "Not available from this publisher. Pick another model.":
        "Bu yayıncıda yok. Başka bir model seç.",
    "No timestamps from this provider.": "Bu sağlayıcı zaman damgası vermiyor.",
    "{page} (unsaved changes)": "{page} (kaydedilmemiş değişiklikler)",
    "Show in history": "Geçmişte göster",
    "Cancel request": "İsteği iptal et",
    "The local editing model is missing.": "Yerel düzenleme modeli eksik.",
    "The assistant is not set up yet.": "Asistan henüz ayarlanmadı.",
    "Assign shortcut": "Kısayol ata",
    "No shortcut yet. Opens the Shortcuts settings.":
        "Henüz kısayol yok. Kısayol ayarlarını açar.",
    "Previous reply": "Önceki yanıt",
    "Chat only": "Yalnızca sohbet",
    "Cleanup": "Temizleme",
    "Ask by voice": "Sesle sor",
    "Edit word": "Kelimeyi düzenle",
    "Add a word": "Kelime ekle",
    "Adds the profile's preferences to the dictation cleanup instruction. A "
    "cleanup instruction of your own replaces the built-in one, and the style "
    "is still added after it; switch this off to use your own instruction "
    "alone. Applies to every profile.":
        "Profilin tercihlerini dikte temizleme talimatına ekler. Kendi temizleme "
        "talimatın yerleşik talimatın yerine geçer ve üslup yine de arkasına "
        "eklenir; kendi talimatını tek başına kullanmak için bunu kapat. Bütün "
        "profillere uygulanır.",
    "Matching": "Eşleşme",
    "Used when no other profile matches.": "Başka hiçbir profil eşleşmezse kullanılır.",
    "Writing": "Yazım",
    "Extra instructions": "Ek talimatlar",
    "Sentence length": "Cümle uzunluğu",
    "Yesterday": "Dün",
    "{day} {month}": "{day} {month}",
    "Jan": "Oca", "Feb": "Şub", "Mar": "Mar", "Apr": "Nis", "May": "May",
    "Jun": "Haz", "Jul": "Tem", "Aug": "Ağu", "Sep": "Eyl", "Oct": "Eki",
    "Nov": "Kas", "Dec": "Ara",
    "{count} characters selected": "{count} karakter seçili",
    "Original": "Orijinal",
    "Cleanup instructions": "Temizleme talimatları",
    "All profiles": "Bütün profiller",
    "Use profile styles": "Profil üsluplarını kullan",
    "Match by program": "Programa göre eşleştir",
    "Enable translation": "Çeviriyi aç",
    "Use learned styles": "Öğrenilen üslubu kullan",
    "Default (automatic unavailable)": "Varsayılan (otomatik kullanılamıyor)",
    "Not used on this desktop.": "Bu masaüstünde kullanılmıyor.",
    "Skip silent recordings": "Sessiz kayıtları atla",
    "A recording with no speech in it is dropped without calling the API.":
        "İçinde konuşma olmayan kayıt API'ye gönderilmeden atılır.",
    "Remove phrases invented during silence": "Sessizlikte uydurulan cümleleri at",
    "Just now": "Az önce",
    "Recent": "Son kayıtlar",
    "Show all": "Tümünü göster",
    "Open in History": "Geçmişte aç",
    "{shortcut} and this button copy the text.": "{shortcut} ve bu düğme metni kopyalar.",
    "{shortcut} pastes into your app. This button copies.":
        "{shortcut} metni uygulamana yapıştırır. Bu düğme kopyalar.",
    "This button copies the text.": "Bu düğme metni kopyalar.",
    "{shortcut} starts and stops dictation in any program.":
        "{shortcut} her programda dikteyi başlatıp durdurur.",
    "Stop and copy": "Durdur ve kopyala",
    "Conversation": "Konuşma",
    "You asked: {question}": "Sorun: {question}",
    "Copy this reply": "Bu yanıtı kopyala",
    "System audio": "Sistem sesi",
    "New conversation": "Yeni konuşma",
    "No sound from either side. Check the sources in Settings.":
        "İki taraftan da ses gelmiyor. Kaynakları Ayarlar'dan kontrol et.",
    "No sound from the microphone.": "Mikrofondan ses gelmiyor.",
    "No system audio yet. Is the other side playing?":
        "Henüz sistem sesi yok. Karşı taraf duyuluyor mu?",
    "Cloud service": "Bulut hizmeti",
    "Paste a key from OpenRouter, OpenAI, Groq or Google.":
        "OpenRouter, OpenAI, Groq ya da Google anahtarını yapıştır.",
    "On this computer": "Bu bilgisayarda",
    "Download a speech model; nothing leaves this machine.":
        "Bir konuşma modeli indir; hiçbir şey bu makineden çıkmaz.",
    "All set. Press {shortcut} in any program and start talking.":
        "Hazır. Herhangi bir programda {shortcut} tuşlarına bas ve konuşmaya başla.",
    "Transcribe the kept recording again.": "Saklanan kaydı yeniden yazıya dök.",
    "The recording is gone; dictate it again.": "Kayıt yok; yeniden dikte et.",
    "Recording now": "Şu an kaydediliyor",
    "Ask by voice; the conversation shows here.":
        "Sesle sor; konuşma burada görünür.",
    "Transcription failed. {reason}": "Yazıya dökme başarısız oldu. {reason}",
    "{model} (default)": "{model} (varsayılan)",
    "Assistant request failed": "Asistan isteği başarısız oldu",
    "Dictation failed": "Dikte başarısız oldu",
    "History size": "Geçmiş boyutu",
    "New conversation after inactivity": "Hareketsizlikte yeni konuşma",
    "Enable in Assistant": "Asistan'da aç",
    "Turns on Ask about the selected text.": "Seçili metin hakkında sor özelliğini açar.",
    "Left empty, the {variable} environment variable is used.":
        "Boş bırakılırsa {variable} ortam değişkeni kullanılır.",
    "Key set": "Anahtar girildi",
    "Paste your key": "Anahtarını yapıştır",
    "Paste your key (optional)": "Anahtarını yapıştır (isteğe bağlı)",
    "Active profile": "Etkin profil",
    "Saved rules (not used on this desktop)": "Kayıtlı kurallar (bu masaüstünde kullanılmıyor)",
    "Edit {name}": "{name} profilini düzenle",
    "When nothing else matches": "Başka hiçbiri eşleşmezse",
    "Chosen by hand": "Elle seçilir",
    "Pick automatically": "Otomatik seç",
    "All model settings": "Bütün model ayarları",
    "One key also writes meeting minutes and cleans transcripts up.":
        "Tek anahtar toplantı tutanağı da yazar, metni de temizler.",
    "Get a key": "Anahtar al",
    "Opens the service's key page in your browser.":
        "Hizmetin anahtar sayfasını tarayıcıda açar.",
    "Service": "Hizmet",
    "Connect a transcription service": "Bir yazıya dökme hizmeti bağla",
    "Transcribe on this computer": "Bu bilgisayarda yazıya dök",
    "Save and start": "Kaydet ve başla",
    "Download and use": "İndir ve kullan",
    "Use this model": "Bu modeli kullan",
    "Recording a command": "Komut kaydediliyor",
    "Recording a meeting": "Toplantı kaydediliyor",
    "Working": "Çalışıyor",
    "Done": "Bitti",
    "Warning": "Uyarı",
    "Cleanup failed. Pasted the raw text.": "Temizleme başarısız oldu. Ham metin yapıştırıldı.",
    "Cleanup failed. Copied the raw text.": "Temizleme başarısız oldu. Ham metin kopyalandı.",
    "Input level": "Giriş seviyesi",
    "Resize the list": "Listeyi yeniden boyutlandır",
    "Working in the browser…": "Tarayıcıda çalışıyor…",
    "{service} ended with an error.": "{service} bir hatayla bitti.",
    "to start, again to stop and copy": "ile başlat, bir daha basınca durdur ve kopyala",
    "to start, again to stop and paste": "ile başlat, bir daha basınca durdur ve yapıştır",
    "Open the minutes in a window": "Tutanağı ayrı bir pencerede aç",
    "Assign a shortcut to dictate into any program.":
        "Herhangi bir programa dikte etmek için bir kısayol ata.",
    "Transcribe audio on this computer.": "Sesi bu bilgisayarda yazıya dök.",
    "Record": "Kayda başla",
    "All set. Press": "Hazır. Herhangi bir programda",
    "in any program and start talking.": "tuşlarına bas ve konuşmaya başla.",
    "Speech: {model}": "Ses: {model}",
    "Server default": "Sunucu varsayılanı",
    "Provider: {service}": "Sağlayıcı: {service}",
    "No words yet.": "Henüz kelime yok.",
    "Pick by program in front": "Öndeki programa göre seç",
    "Profile options": "Profil seçenekleri",
    "Use this profile": "Bu profili kullan",
    "In use": "Kullanımda",
    "Dictation picks a profile by the program in front, and this one when none of them lists it.":
        "Dikte, profili öndeki programa göre seçer; hiçbiri o programı listelemiyorsa bunu kullanır.",
    "Dictation uses this profile.": "Dikte bu profili kullanıyor.",
    "Use this profile for every dictation.": "Her diktede bu profili kullan.",
    "Reset after inactivity": "Hareketsizlikten sonra sıfırla",
    "Paste the answer into the focused window": "Yanıtı odaktaki pencereye yapıştır",
    "Drop an audio or video file here": "Bir ses ya da video dosyasını buraya bırak",
    "Speech engine": "Konuşma motoru",
    "{model} (English)": "{model} (İngilizce)",
    "Recommended": "Önerilen",
    "The model this computer runs best.": "Bu bilgisayarın en iyi çalıştırdığı model.",
    "Cleanup can be set up on this computer later, under Models in Settings.":
        "Temizleme daha sonra Ayarlar'daki Modeller sayfasından bu bilgisayarda kurulabilir.",
    "Downloaded": "İndirildi",
    "Download {size}": "İndirme: {size}",
    "needs about {size} of memory": "yaklaşık {size} bellek ister",
    "The memory figure is an estimate.": "Bellek miktarı bir tahmindir.",
    "Downloading the speech engine…": "Konuşma motoru indiriliyor…",
    "Downloading the model…": "Model indiriliyor…",
    "Cleanup still sends the text to {service}.": "Temizleme metni yine de {service} hizmetine gönderir.",
    "Nothing leaves this computer.": "Hiçbir şey bu bilgisayardan çıkmaz.",
    "Speech model": "Konuşma modeli",
    "Today {time}": "Bugün {time}",
    "Yesterday {time}": "Dün {time}",
    "More about {topic}": "{topic} hakkında daha fazla bilgi",
    "More information": "Daha fazla bilgi",
    "Clean up with {service}": "{service} ile temizle",
    "Please wait": "Lütfen bekleyin",
    "to stop and paste": "durdurup yapıştırmak için",
    "to stop and copy": "durdurup kopyalamak için",
    "Picks a profile by the program in front.": "Profili öndeki programa göre seçer.",
    "Next dictation uses: {profile}": "Sonraki dikte bunu kullanır: {profile}",
    "Profile for the next dictation: {profile}": "Sonraki diktenin profili: {profile}",
    "Edit profiles…": "Profilleri düzenle…",
    "New": "Yeni",
}
